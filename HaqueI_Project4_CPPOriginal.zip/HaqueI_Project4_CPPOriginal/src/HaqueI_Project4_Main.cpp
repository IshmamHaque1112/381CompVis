//============================================================================
// Name        : HaqueI_Project4_Main.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <cmath>
#include <stdio.h>
#include <math.h>
#include <string>
#include <algorithm>
using namespace std;
int numRows, numCols, minVal, maxVal;
int trueNumCC;
int newLabel;
int NonZeroNeighborAry[5];// 5 is the max number of neighbors you have to check. For easy programming,
						//you may consider using this 1-D array to store pixel (i, j)’s non-zero neighbors during pass 1 and pass2.
class CCpropertyelement{
public:
	int label=0; // The component label
	int numPixels=0; // total number of pixels in the cc.
	int minR=0; // with respect to the input image.
	int minC=0; // with respect to the input image.
	int maxR=0; // with respect to the input image.
	int maxC=0; // with respect to the input image.

};
CCpropertyelement defaultelement;
CCpropertyelement *CCproperty=NULL;
void zero2DAry(int** zeroFramedAry, int a, int b) {
	  for(int i=0;i<a;i++) {
		for(int j=0;j<b;j++) {
		 zeroFramedAry[i][j]=0;
		}
	  }
 }
void loadImage(ifstream& inFile,int** zeroFramedAry){
  int row=1,col=1;
  int counter=0;
  string loaded="";
  while(inFile>>loaded) {
  	int currval=stoi(loaded);
  	zeroFramedAry[row][col]=currval;
  	counter++;
  	col++;
  	if(col==1+numCols){
  	 row=row+1;
  	 col=1;
  	}
  	if(counter==numRows*numCols) break;
  }
}
void conversion(int** zeroFramedAry){
	for(int r=1;r<numRows+1;r++){
		 for(int c=1;c<numCols+1;c++){
		   if(zeroFramedAry[r][c]==0) zeroFramedAry[r][c]=1;
		   else if(zeroFramedAry[r][c]==1) zeroFramedAry[r][c]=0;
		}
	 }
}
void imgReformat(int** inAry,ofstream& outFile){
	int newmax=0;
	int newmin=100000;
	for(int r=1;r<numRows+1;r++){
	 for(int c=1;c<numCols+1;c++){
	   if(newmax<inAry[r][c]) newmax=inAry[r][c];
	   if(newmin>inAry[r][c]) newmin=inAry[r][c];
	 }
	}
	outFile<<"Rows "<<numRows<<" Cols "<<numCols<<" minVal "<<newmin<<" maxVal "<<newmax<<"\n";
	string str=to_string(maxVal); // C++ build-in
	int Width=str.length();
	for(int r=1;r<numRows+1;r++){
	 for(int c=1;c<numCols+1;c++){
	  if(inAry[r][c]!=0) outFile<<inAry[r][c];
	  if(inAry[r][c]==0) outFile<<".";
	  str=to_string(inAry[r][c]);
	  for(int WW=str.length()-1;WW<Width+1;WW++){
		 outFile<<" ";
	  }
	 }
	 outFile<<"\n";
	}
}
void printEQAry(int newLabel,ofstream& RFprettyPrintFile,int *EQAry){
	RFprettyPrintFile<<"Printing equivalency array from index 1 \n";
	for(int i=1;i<=newLabel;i++){
	  RFprettyPrintFile<<EQAry[i]<<" ";
	}
	RFprettyPrintFile<<"\n";
}
void negative1D(int inAry[],int a){
	for(int i=0;i<a;i++){
	 inAry[i]=-1;
	}
}
int processneighbors(int inAry[],int a){
    sort(inAry,inAry+a);
    int current=0;
    int count=0;
	for(int i=0;i<a;i++){
	 if((inAry[i]!=0)&&(inAry[i]!=current)){
		current=inAry[i];
		count++;
	 }
	}
	return count;
}
int processneighbors2(int inAry[],int a){
    sort(inAry,inAry+a);
    for(int i=0;i<a;i++){
     int val=inAry[i];
     if(val!=0) return val;
    }
	return -1;
}
int manageEQAry(int* EQAry,int newLabel){
	int readLabel=0;
	for(int index=1;index<=newLabel;index++){
		if(index!=EQAry[EQAry[index]]){
			EQAry[index]=EQAry[EQAry[index]];
		}
		else{
			readLabel++;
			EQAry[index]=readLabel;
		}
	}
	return readLabel;
}
void connect4Pass1(int** zeroFramedAry,int& newLabel,int* EQAry){
	for(int r=1;r<numRows+1;r++){
		 for(int c=1;c<numCols+1;c++){
		  if(zeroFramedAry[r][c]>0){
			int nonzero=0;
			int elemcase=-1;
			int neighbora=zeroFramedAry[r-1][c];
			int neighborb=zeroFramedAry[r][c-1];
			bool allsame=true;
			if(neighbora>0){
			  NonZeroNeighborAry[nonzero]=neighbora;
			  nonzero++;
			}
			if(neighborb>0){
			  NonZeroNeighborAry[nonzero]=neighborb;
			  nonzero++;
			}
			if(nonzero>0){
			for(int i=0;i<nonzero;i++){
			  if(NonZeroNeighborAry[i]!=NonZeroNeighborAry[0]){
				  allsame=false;
				  break;
			  }
			}
			}
			if(nonzero==0){
			 elemcase=1;
			 newLabel++;
			 //EQAry[zeroFramedAry[r][c]]=newLabel;
			 zeroFramedAry[r][c]=newLabel;
			}
			else if(allsame==true){
				elemcase=2;
				zeroFramedAry[r][c]=NonZeroNeighborAry[0];
			}
			else if(allsame==false){
			 elemcase=3;
			 int minLabel=NonZeroNeighborAry[0];
			 for(int i=0;i<nonzero;i++){
			 	if(NonZeroNeighborAry[i]<minLabel) minLabel=NonZeroNeighborAry[i];
			 }
			 zeroFramedAry[r][c]=minLabel;
			 for(int i=0;i<nonzero;i++){
			  if(EQAry[NonZeroNeighborAry[i]] > minLabel){
			    EQAry[NonZeroNeighborAry[i]] = minLabel;
			  }
			 }
			}
		  }
		 }
		}
}
void connect4Pass2(int** zeroFramedAry,int* EQAry){
	for(int r=numRows;0<r;r--){
		  for(int c=numCols;0<c;c--){
		  if(zeroFramedAry[r][c]>0){
			int nonzero=0;
			int zero1=false;
			int elemcase=0;
			int neighborc=zeroFramedAry[r][c+1];
			int neighbord=zeroFramedAry[r+1][c];
			bool allsame=true;
			if(neighborc>0){
			  NonZeroNeighborAry[nonzero]=neighborc;
			  nonzero++;
			}
			if(neighbord>0){
			  NonZeroNeighborAry[nonzero]=neighbord;
			  nonzero++;
			}
			if(nonzero==0) zero1=true;
			if(zeroFramedAry[r][c]>0){
			  NonZeroNeighborAry[nonzero]=zeroFramedAry[r][c];
			  nonzero++;
			}
			if(nonzero>0){
			  for(int i=0;i<nonzero;i++){
			   if(NonZeroNeighborAry[i]!=NonZeroNeighborAry[0]){
				allsame=false;
				break;
				}
			}
			if(zero1==true){
			 elemcase=1;
			 zeroFramedAry[r][c]=EQAry[zeroFramedAry[r][c]];
			}
			else if(allsame==true){
			  elemcase=2;
			  zeroFramedAry[r][c]=EQAry[zeroFramedAry[r][c]];
			}
			else if(allsame==false){
			 elemcase=3;
			 int minLabel=NonZeroNeighborAry[0];
			 for(int i=0;i<nonzero;i++){
			  if(NonZeroNeighborAry[i]<minLabel) NonZeroNeighborAry[i]=minLabel;
			 }
	         if(zeroFramedAry[r][c]>minLabel){
	        	EQAry[zeroFramedAry[r][c]]=minLabel;
	        	zeroFramedAry[r][c]=minLabel;
	         }
			}
		  }
		 }
		}
		}
}
void connect8Pass1(int** zeroFramedAry,int& newLabel,int* EQAry){
	for(int r=1;r<numRows+1;r++){
	 for(int c=1;c<numCols+1;c++){
	  if(zeroFramedAry[r][c]>0){
		int nonzero=0;
		int elemcase=-1;
		int neighbora=zeroFramedAry[r-1][c-1];
		int neighborb=zeroFramedAry[r-1][c];
		int neighborc=zeroFramedAry[r-1][c+1];
		int neighbord=zeroFramedAry[r][c-1];
		bool allsame=true;
		if(neighbora>0){
		  NonZeroNeighborAry[nonzero]=neighbora;
		  nonzero++;
		}
		if(neighborb>0){
		  NonZeroNeighborAry[nonzero]=neighborb;
		  nonzero++;
		}
		if(neighborc>0){
		   NonZeroNeighborAry[nonzero]=neighborc;
		   nonzero++;
		}
		if(neighbord>0){
		   NonZeroNeighborAry[nonzero]=neighbord;
		   nonzero++;
		}
		if(nonzero>0){
		for(int i=0;i<nonzero;i++){
		  if(NonZeroNeighborAry[i]!=NonZeroNeighborAry[0]){
			  allsame=false;
			  break;
		  }
		}
		}
		if(nonzero==0){
		 elemcase=1;
		 newLabel++;
		 //EQAry[zeroFramedAry[r][c]]=newLabel;
		 zeroFramedAry[r][c]=newLabel;
		}
		else if(allsame==true){
			elemcase=2;
			zeroFramedAry[r][c]=NonZeroNeighborAry[0];
		}
		else if(allsame==false){
		 elemcase=3;
		 int minLabel=NonZeroNeighborAry[0];
		 for(int i=0;i<nonzero;i++){
		 	if(NonZeroNeighborAry[i]<minLabel) minLabel=NonZeroNeighborAry[i];
		 }
		 zeroFramedAry[r][c]=minLabel;
		 for(int i=0;i<nonzero;i++){
		  if(EQAry[NonZeroNeighborAry[i]] > minLabel){
		    EQAry[NonZeroNeighborAry[i]] = minLabel;
		  }
		 }
		}
	  }
	 }
	}
}
void connect8Pass2(int** zeroFramedAry,int* EQAry){
	for(int r=numRows;0<r;r--){
	  for(int c=numCols;0<c;c--){
	  if(zeroFramedAry[r][c]>0){
		int nonzero=0;
		int zero1=false;
		int elemcase=0;
		int neighbore=zeroFramedAry[r][c+1];
		int neighborf=zeroFramedAry[r+1][c-1];
		int neighborg=zeroFramedAry[r+1][c];
		int neighborh=zeroFramedAry[r+1][c+1];
		bool allsame=true;
		if(neighbore>0){
		  NonZeroNeighborAry[nonzero]=neighbore;
		  nonzero++;
		}
		if(neighborf>0){
		  NonZeroNeighborAry[nonzero]=neighborf;
		  nonzero++;
		}
		if(neighborg>0){
		  NonZeroNeighborAry[nonzero]=neighborg;
		  nonzero++;
		}
		if(neighborh>0){
		  NonZeroNeighborAry[nonzero]=neighborh;
		  nonzero++;
		}
		if(nonzero==0) zero1=true;
		if(zeroFramedAry[r][c]>0){
		  NonZeroNeighborAry[nonzero]=zeroFramedAry[r][c];
		  nonzero++;
		}
		if(nonzero>0){
		  for(int i=0;i<nonzero;i++){
		   if(NonZeroNeighborAry[i]!=NonZeroNeighborAry[0]){
			allsame=false;
			break;
			}
		}
		if(zero1==true){
		 elemcase=1;
		 zeroFramedAry[r][c]=EQAry[zeroFramedAry[r][c]];
		}
		else if(allsame==true){
		  elemcase=2;
		  zeroFramedAry[r][c]=EQAry[zeroFramedAry[r][c]];
		}
		else if(allsame==false){
		 elemcase=3;
		 int minLabel=NonZeroNeighborAry[0];
		 for(int i=0;i<nonzero;i++){
		  if(NonZeroNeighborAry[i]<minLabel) NonZeroNeighborAry[i]=minLabel;
		 }
         if(zeroFramedAry[r][c]>minLabel){
        	EQAry[zeroFramedAry[r][c]]=minLabel;
        	zeroFramedAry[r][c]=minLabel;
         }
		}
	  }
	 }
	}
	}
}
void printCCproperty(CCpropertyelement* CCproperty,ofstream& propertyFile,int** zeroFramedAry){
	int newmax=0;
	int newmin=100000;
    for(int r=1;r<numRows+1;r++){
	 for(int c=1;c<numCols+1;c++){
		if(newmax<zeroFramedAry[r][c]) newmax=zeroFramedAry[r][c];
		if(newmin>zeroFramedAry[r][c]) newmin=zeroFramedAry[r][c];
	  }
	 }
	 propertyFile<<"Rows "<<numRows<<" Cols "<<numCols<<" minVal "<<newmin<<" maxVal "<<newmax<<"\n";
	 propertyFile<<"Number of components "<<trueNumCC<<"\n";
	 for(int i=0;i<trueNumCC;i++){
		 propertyFile<<CCproperty[i].label<<"\n";
		 propertyFile<<CCproperty[i].numPixels<<"\n";
		 propertyFile<<CCproperty[i].minR<<" "<<CCproperty[i].minC<<"\n";
		 propertyFile<<CCproperty[i].maxR<<" "<<CCproperty[i].maxC<<"\n";

	 }
}
void connectPass3(int** zeroFramedAry,int* EQAry,CCpropertyelement* &CCproperty,int trueNumCC,ofstream& deBugFile){
 deBugFile<<"entering connectPas3 method \n";
 for(int i = 1;i<=trueNumCC;i++){
  CCpropertyelement CCpropert;
  CCproperty[i]=CCpropert;
  CCproperty[i].label=i;
  CCproperty[i].numPixels=0;
  CCproperty[i].minR=numRows;
  CCproperty[i].maxR=0;
  CCproperty[i].minC=numCols;
  CCproperty[i].maxC=0;
 }
 for(int r=1;r<numRows+1;r++){
   for(int c=1;c<numCols+1;c++){
 	  int val=zeroFramedAry[r][c];
 	  if(val>0){
 		 zeroFramedAry[r][c]=EQAry[val]; // relabeling.
 		 int k=zeroFramedAry[r][c];
 		 CCproperty[k].numPixels=CCproperty[k].numPixels+1;
 		 if(r<CCproperty[k].minR) CCproperty[k].minR=r;
 		 if(r>CCproperty[k].maxR) CCproperty[k].maxR=r;
 		 if(c<CCproperty[k].minC) CCproperty[k].minC=c;
 		 if(c>CCproperty[k].maxC) CCproperty[k].maxC=c;
 	  }
   }
 }
 cout<<CCproperty[0].maxR<<endl;
deBugFile<<"leaving connectPas3 method \n";
}
void drawBoxes(int** zeroFramedAry,CCpropertyelement* CCproperty,int trueNumCC){
 for(int index=1;index<=trueNumCC;index++){
	 int minRow=CCproperty[index].minR;
	 int minCol=CCproperty[index].minC;
	 int maxRow=CCproperty[index].maxR;
	 int maxCol=CCproperty[index].maxC;
	 int label=CCproperty[index].label;
	 for(int i=minCol;i<=maxCol;i++){
		 zeroFramedAry[minRow][i]=label;
		 zeroFramedAry[maxRow][i]=label;
	 }
	 for(int i=minRow;i<=maxRow;i++){
	 	zeroFramedAry[i][minCol]=label;
	 	zeroFramedAry[i][maxCol]=label;
	 }
 }
}
// In the Cartesian coordinate system, any rectangu
void connected4(int** zeroFramedAry,int& newLabel,int* EQAry,ofstream& RFprettyPrintFile,ofstream& deBugFile){
 deBugFile<<"entering connected4 method"<<"\n";
 connect4Pass1(zeroFramedAry,newLabel,EQAry);
 deBugFile<<"After connected4 pass1, newLabel="<<newLabel<<"\n"; // print newLable
 RFprettyPrintFile<<"After connected4 pass1"<<"\n"; // print newLable
 imgReformat(zeroFramedAry, RFprettyPrintFile);
 printEQAry(newLabel, RFprettyPrintFile,EQAry); // print the EQAry up to newLable with proper caption
 connect4Pass2(zeroFramedAry, EQAry);
 deBugFile<<"After connected4 pass2, newLabel="<<newLabel<<"\n"; // print newLable
 RFprettyPrintFile<<"After connected4 pass2"<<"\n"; // print newLable
 imgReformat(zeroFramedAry, RFprettyPrintFile);
 printEQAry(newLabel, RFprettyPrintFile,EQAry); // print the EQAry up to newLabel with proper caption
 trueNumCC=manageEQAry(EQAry, newLabel);
 printEQAry(newLabel, RFprettyPrintFile,EQAry); // print the EQAry up to newLabel with proper caption
 int newMin=0;
 int newMax=trueNumCC;
 CCproperty=(CCpropertyelement *) malloc(sizeof(CCpropertyelement) * (trueNumCC+1));
 deBugFile<<"In connected4, after manage EQAry, trueNumCC ="<<trueNumCC<<"\n"; // print trueNumCC
 RFprettyPrintFile<<"After connected4 pass3"<<"\n"; // print newLable
 connectPass3(zeroFramedAry, EQAry, CCproperty, trueNumCC, deBugFile); // see algorithm below.
 imgReformat(zeroFramedAry, RFprettyPrintFile);
 printEQAry(newLabel, RFprettyPrintFile,EQAry); // print the EQAry up to newLabel with proper caption
 deBugFile<<"Leaving connected4 method number of components "<<trueNumCC<<"\n";
}
void connected8(int** zeroFramedAry,int& newLabel,int* EQAry,ofstream& RFprettyPrintFile,ofstream& deBugFile){
 deBugFile<<"entering connected8 method"<<"\n";
 connect8Pass1(zeroFramedAry,newLabel,EQAry);
 deBugFile<<"After connected8 pass1, newLabel="<<newLabel<<"\n"; // print newLable
 RFprettyPrintFile<<"After connected8 pass1"<<"\n"; // print newLable
 imgReformat(zeroFramedAry, RFprettyPrintFile);
 printEQAry(newLabel, RFprettyPrintFile,EQAry); // print the EQAry up to newLable with proper caption
 connect8Pass2(zeroFramedAry, EQAry);
 deBugFile<<"After connected8 pass2, newLabel="<<newLabel<<"\n"; // print newLable
 RFprettyPrintFile<<"After connected8 pass2"<<"\n"; // print newLable
 imgReformat(zeroFramedAry, RFprettyPrintFile);
 printEQAry(newLabel, RFprettyPrintFile,EQAry); // print the EQAry up to newLabel with proper caption
 trueNumCC=manageEQAry(EQAry, newLabel);
 printEQAry(newLabel, RFprettyPrintFile,EQAry); // print the EQAry up to newLabel with proper caption
 int newMin=0;
 int newMax=trueNumCC;
 CCproperty=(CCpropertyelement *) malloc(sizeof(CCpropertyelement) * (trueNumCC+1));
 deBugFile<<"In connected8, after manage EQAry, trueNumCC ="<<trueNumCC<<"\n"; // print trueNumCC
 RFprettyPrintFile<<"After connected8 pass3"<<"\n"; // print newLable
 connectPass3(zeroFramedAry, EQAry, CCproperty, trueNumCC, deBugFile); // see algorithm below.
 imgReformat(zeroFramedAry, RFprettyPrintFile);
 printEQAry(newLabel, RFprettyPrintFile,EQAry); // print the EQAry up to newLabel with proper caption
 deBugFile<<"Leaving connected8 method number of components "<<trueNumCC<<"\n";
}
int main(int argc,char** argv) {
	ifstream inFile;
	inFile.open(argv[1]);
	int Connectness=atoi(argv[2]);
	char option=*(argv[3]);
	ofstream RFprettyPrintFile,labelFile,propertyFile,deBugFile;
	RFprettyPrintFile.open(argv[4]);
	labelFile.open(argv[5]);
	propertyFile.open(argv[6]);
	deBugFile.open(argv[7]);
	int numberindex1=0,numberindex2=0;
	string currentst1="";
	while(inFile>>currentst1) {
		  numberindex1++;
		  int currval1= stoi(currentst1);
		  if(numberindex1==1) numRows=currval1;
		  if(numberindex1==2) numCols=currval1;
		  if(numberindex1==3) minVal=currval1;
		  if(numberindex1==4) {
		    maxVal=currval1;
		    break;
		  }
	}
	int **zeroFramedAry = (int **) malloc(sizeof(int*) * (numRows+2));
	for(int i = 0; i < numRows+2; i++){
		zeroFramedAry[i] = (int *) malloc(sizeof(int) * (numCols+2));
	}
	newLabel=0;
	zero2DAry(zeroFramedAry,numRows+2,numCols+2);
	loadImage(inFile,zeroFramedAry);
	if(option=='y'||option=='Y'){
	 conversion(zeroFramedAry);
	}
	int *EQAry=(int *) malloc(sizeof(int) * ((numRows*numCols)/4)); // a 1-D array, of size (numRows * numCols) / 4
	int eqsize=(numRows*numCols)/4;
	for(int r=1;r<numRows+1;r++){
		 for(int c=1;c<numCols+1;c++){
		  cout<<zeroFramedAry[r][c];
		  cout<<" ";
		 }
		 cout<<"\n";
		}
	for(int i=0;i<eqsize;i++){
	 EQAry[i]=i;
	}
	//negative1D(NonZeroNeighborAry,5);
	if(Connectness==4) connected4(zeroFramedAry, newLabel, EQAry, RFprettyPrintFile, deBugFile);
	if(Connectness==8) connected8(zeroFramedAry, newLabel, EQAry, RFprettyPrintFile, deBugFile);
	imgReformat(zeroFramedAry, labelFile);
	printCCproperty(CCproperty,propertyFile,zeroFramedAry);
	drawBoxes(zeroFramedAry, CCproperty, trueNumCC); // draw on zeroFramed image.
	imgReformat(zeroFramedAry, RFprettyPrintFile);
	inFile.close();
	RFprettyPrintFile.close();
	labelFile.close();
	propertyFile.close();
	deBugFile.close();
	return 0;
}
