//============================================================================
// Name        : HaqueI_Project02_Main.cpp
// Author      : Ishmam Haque
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <string>
using namespace std;

int main(int argc,char** argv) {

	int numRows=0, numCols=0, minVal=0, maxVal=0,thrValue=0;
	ofstream outFile2;
	outFile2.open(argv[3]);
	cout<<"Input your threshold number"<<endl;
	outFile2<<"Input your threshold number \n";
	int inItem, outItem;
	cin>>inItem;
	thrValue=inItem;
	cout<<"The threshold value is "<< thrValue<<endl;
	outFile2<<"The threshold value is "<< thrValue<<"\n";
	ifstream inFile1;
	inFile1.open(argv[1]);
	ofstream outFile1;
	outFile1.open(argv[2]);
	int numberindex=0;
	string currentst="";
	while(inFile1>>currentst) {
	numberindex++;
	int currval= stoi(currentst);
	if(numberindex==1) numRows=currval;
	if(numberindex==2) numCols=currval;
	if(numberindex==3) minVal=currval;
	if(numberindex==4) {
	maxVal=currval;
	break;
	}
	}
	int rownum=1;
	int colnum=0;
	int newmin=0;
	int newmax=0;
	string currstring="";
	if(minVal<thrValue) newmin=0;
	if(minVal>=thrValue) newmin=minVal;
	if(maxVal<thrValue) newmax=0;
	if(maxVal>=thrValue) newmax=maxVal;
	outFile1<<numRows<<" "<<numCols<<" "<<newmin<<" "<<newmax<<"\n";
	while(inFile1>>currentst) {
	numberindex++;
	colnum++;
	int currval= stoi(currentst);
	if(currval<thrValue) currstring=currstring+"0 ";
	else if(currval>=thrValue) currstring=currstring+currentst+" ";
	if(colnum==numCols) {
	outFile1<<currstring<<"\n";
	currstring="";
	if(rownum==numRows) break;
	rownum++;
	colnum=0;
	}
	}
	inFile1.close();
	outFile1.close();
	outFile2.close();
	return 0;
}
