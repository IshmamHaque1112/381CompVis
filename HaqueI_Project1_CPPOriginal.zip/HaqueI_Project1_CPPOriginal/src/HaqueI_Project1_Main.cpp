//============================================================================
// Name        : HaqueI_Project1_CPPOriginal.cpp
// Author      :
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <cmath>
#include <stdio.h>
#include <math.h>
#include <string>
using namespace std;
int maxHeight;
int arraysize;
//int *histAry;
int loadHist(int *histAry,ifstream& inFile1,int arraysize) {
  int maximumvalue=0;
  int currnum=-1;
  int currvalue=-1;
  bool isitindex=true;
  string currentst="";
  while(inFile1>>currentst) {
  		int currval= stoi(currentst);
  		if(isitindex==true){
  		 currnum=currval;
  		}
  		if(isitindex==false){
  		 currvalue=currval;
  		 histAry[currnum]=currvalue;
  		}
  		if((currnum==arraysize-1)&&(isitindex==false)) {
  		 break;
  		}
  		isitindex=!isitindex;
 }
  maximumvalue=histAry[0];
  for(int i=0;i<arraysize;i++){
	if(maximumvalue<=histAry[i]) maximumvalue=histAry[i];
  }
  return maximumvalue;
}
int deepestConcavity(int x1,int y1,int x2,int y2,int *histAry,ofstream& deBugFile){
	deBugFile<<"Entering deepestConcavity method"<<"\n";
	cout<<"Entering deepestConcavity method"<<endl;
	double m=((double)(y2-y1))/((double)(x2-x1));
	double b=((double) y1)-(m*((double) x1));
	int maxGap=0;
	int first=x1;
	int second=x2;
	int x=first;
	int thr=first;
	while(x<=second){
	 int y=(int)((m*x)+b);
     int gap=(abs)(histAry[x]-y);
	 if(gap>maxGap){
	  maxGap=gap;
	  thr=x;
	 }
	 if((maxGap==gap) && (histAry[x]<histAry[thr])) thr=x;
	 x++;
	}
	deBugFile<<"leaving deepestConcavity method, maxGap is "<<maxGap<<" and thr is "<<thr<<"\n";
	cout<<"leaving deepestConcavity method, maxGap is "<<maxGap<<" and thr is "<<thr<<endl;
	return thr;
}
void dispHist(int *histAry,ofstream& outFile1,int arraysize){
	for(int i=0;i<arraysize;i++){
	  outFile1<<i<<" ("<<histAry[i]<<"):";
	  for(int j=0;j<histAry[i];j++){
		outFile1<<"+";
	  }
	  outFile1<<"\n";
   }
}
double modifiedGauss(int x,double mean,double var,int &maxHeight){
 double doubleHeight=(double) maxHeight;
 double doublex=(double) x;
 double simplified=((doublex-mean)*(doublex-mean))/(2*var);
 double solution=(doubleHeight*exp(-1.0*simplified));
 return solution;
// double check the equation!!
}
double computeMean(int leftIndex,int rightIndex,int &maxHeight,int *histAry,ofstream& deBugFile){
 deBugFile<<"Entering computeMean method"<<"\n";// debug print
 //deBugFile<<"Mean "<<leftIndex<<" "<<rightIndex<<" "<<maxHeight<<"\n";
 cout<<"Entering computeMean method"<<endl;
 maxHeight=0;
 int sum=0;
 int numPixels=0;
 for(int index=leftIndex;index<rightIndex;index++){
  //cout<<" "<<histAry[index]<<" "<<index<<endl;
  sum+=histAry[index]*index;
  numPixels+=histAry[index];
  if(histAry[index]>maxHeight) maxHeight=histAry[index];
 }
 //cout<<" Sum "<<sum<<" / numpixels "<<numPixels<<endl;
 double result=((double) sum)/((double) numPixels);
 deBugFile<<"Leaving computeMean method, result is "<<result<<" and max height "<<maxHeight<<"\n";
 cout<<"Leaving computeMean method, result is "<<result<<" and max height "<<maxHeight<<endl;
 return result;
}
double computeVar(int leftIndex,int rightIndex,double mean,int *histAry,ofstream& deBugFile){
 deBugFile<<"Entering computeVar method"<<"\n"; // debug print;
 //deBugFile<<"Var "<<leftIndex<<" "<<rightIndex<<" "<<mean<<"\n";
 cout<<"Entering computeVar method"<<endl; // debug print;
 double sum=0.0;
 int numPixels=0;
 for(int index=leftIndex;index<rightIndex;index++){
  //cout<<" "<<histAry[index]<<" "<<index<<endl;
  double doubleindex= (double) index;
  sum+=((double) histAry[index])*((doubleindex-mean)*(doubleindex-mean));
  numPixels+=histAry[index];
 }
 //cout<<" Sum "<<sum<<" / numpixels "<<numPixels<<endl;
 double result=sum/((double) numPixels);
 deBugFile<<"Leaving computeVar method returning result "<<result<<"\n"; // debug print
 cout<<"Leaving computeVar method returning result "<<result<<endl;
 return result;
}
double fitGauss (int leftIndex,int rightIndex,int *histAry,int *GaussAry,ofstream& deBugFile){
 deBugFile<<"Entering fitGauss method"<<"\n"; // debug print
 //deBugFile<<"Fit "<<leftIndex<<" "<<rightIndex<<" "<<"\n";
 cout<<"Entering fitGauss method"<<endl; // debug print
 double mean;
 double var;
 double sum=0.0;
 double Gval;
 double maxGval;
 mean=computeMean(leftIndex,rightIndex,maxHeight,histAry,deBugFile);
 var=computeVar(leftIndex,rightIndex,mean,histAry,deBugFile);
 for(int index=leftIndex;index<=rightIndex;index++){
	Gval=modifiedGauss(index,mean,var,maxHeight);
	sum+=abs(Gval-((double) histAry[index]));
	GaussAry[index]=(int) Gval;
 }
 deBugFile<<"leaving fitGauss method, sum is "<<sum<<"\n";//debug print
 cout<<"leaving fitGauss method, sum is "<<sum<<endl;
 return sum;
}
int biGaussian (int *histAry,int *GaussAry,int &maxHeight,int minVal,int maxVal,ofstream& deBugFile){
  deBugFile<<"Entering biGaussian method"<<"\n";// debug print
  //deBugFile<<"Bi "<<maxHeight<<" "<<minVal<<" "<<maxVal<<"\n";
  cout<<"Entering biGaussian method"<<endl;
  //for(int i=0;i<arraysize;i++){
  // cout<<histAry[i]<<" "<<i<<endl;
  //}
  double sum1;
  double sum2;
  double total;
  double minSumDiff=999999.0;
  int offSet=(int)((maxVal-minVal)/10);
  int dividePt=offSet;
  int bestThr=dividePt;
  for(int dividePt=offSet;dividePt<(maxVal-offSet);dividePt++){
	//cout<<dividePt<<" "<<bestThr<<" "<<minSumDiff<<endl;
	for(int i=0;i<arraysize;i++){
	  GaussAry[i]=0;
	}
	sum1=fitGauss(0,dividePt,histAry,GaussAry,deBugFile);
	//cout<<"Sum 1"<<endl;
	//for(int i=0;i<arraysize;i++){
	//   cout<<histAry[i]<<" "<<i<<endl;
	//}
	sum2=fitGauss(dividePt,maxVal,histAry,GaussAry,deBugFile);
	//cout<<"sum 2"<<endl;
	//for(int i=0;i<arraysize;i++){
	//	   cout<<histAry[i]<<" "<<i<<endl;
	//}
	total=sum1+sum2;
	if(total<minSumDiff){
	 minSumDiff=total;
	 bestThr=dividePt;
	}
	deBugFile<<"Divide Pt "<<dividePt<<" Sum 1 "<<sum1<<" Sum 2 "<<sum2<<" Total "<<total<<" minSumDiff "<<minSumDiff<<" best Threshold value "<<bestThr<<"\n";
	cout<<"Divide Pt "<<dividePt<<" Sum 1 "<<sum1<<" Sum 2 "<<sum2<<" Total "<<total<<" minSumDiff "<<minSumDiff<<" best Threshold value "<<bestThr<<endl;
  }
  deBugFile<<"leaving biGaussian method,minSumDiff is "<<minSumDiff<<" bestThr is "<<bestThr<<"\n";
  cout<<"leaving biGaussian method,minSumDiff is "<<minSumDiff<<" bestThr is "<<bestThr<<endl;
  return bestThr;
}
int main(int argc,char** argv) {
	cout <<"Processing the histogram on the output.txt. The header given below"<<endl; // prints !!!Hello World!!!
	ifstream inFile1;
	ifstream inFile2;
	inFile1.open(argv[1]);
	inFile2.open(argv[2]);
	ofstream outFile1;
	ofstream deBugFile;
	outFile1.open(argv[3]);
	deBugFile.open(argv[4]);
	int numRows=0, numCols=0, minVal=0, maxVal=0;
	int x1=0,y1=0,x2=0,y2=0;
	int numberindex1=0,numberindex2=0;
	string currentst1="",currentst2="";
	while(inFile1>>currentst1) {
		numberindex1++;
		int currval1= stoi(currentst1);
		if(numberindex1==1) numRows=currval1;
		if(numberindex1==2) numCols=currval1;
		if(numberindex1==3) minVal=currval1;
		if(numberindex1==4) {
		 maxVal=currval1;
		 break;
		}
	}
	deBugFile <<"Processing the histogram on the output.txt. The header given below"<<"\n";
	outFile1<<numRows<<" "<<numCols<<" "<<minVal<<" "<<maxVal<<"\n";
	deBugFile<<numRows<<" "<<numCols<<" "<<minVal<<" "<<maxVal<<"\n";
	while(inFile2>>currentst2) {
		numberindex2++;
		int currval2= stoi(currentst2);
		if(numberindex2==1) x1=currval2;
		if(numberindex2==2) y1=currval2;
		if(numberindex2==3) x2=currval2;
		if(numberindex2==4) {
		 y2=currval2;
		 break;
		}
	}
	arraysize=maxVal+1;
    //int *histAry = new int(arraysize);
	int *histAry = (int *) malloc(sizeof(int) * arraysize);
	for(int i=0;i<arraysize;i++){
	 histAry[i]=0;
	}
	int *GaussAry = (int *) malloc(sizeof(int) * arraysize);
	for(int i=0;i<arraysize;i++){
	  GaussAry[i]=0;
	}
	maxHeight=loadHist(histAry,inFile1,arraysize);
	dispHist(histAry,outFile1,arraysize);
	//for(int i=0;i<arraysize;i++){
	// cout<<histAry[i]<<" "<<i<<endl;
	//}
	outFile1<<"Coordinates for Peak 1 ("<<x1<<","<<y1<<")"<<"\n";
	cout<<"Coordinates for Peak 1 ("<<x1<<","<<y1<<")"<<"\n";
	deBugFile<<"Coordinates for Peak 1 ("<<x1<<","<<y1<<")"<<"\n";
	outFile1<<"Coordinates for Peak 2 ("<<x2<<","<<y2<<")"<<"\n";
	cout<<"Coordinates for Peak 2 ("<<x2<<","<<y2<<")"<<"\n";
	deBugFile<<"Coordinates for Peak 2 ("<<x2<<","<<y2<<")"<<"\n";
	int deepestThrVal=deepestConcavity(x1,y1,x2,y2,histAry,deBugFile);
	outFile1<<"Deepest Threshold Value is "<<deepestThrVal<<"\n";
	int BiGaussThrVal=biGaussian(histAry,GaussAry,maxHeight,minVal,maxVal,deBugFile);
	cout<<"BiGauss Threshold Value "<<BiGaussThrVal<<endl;
	deBugFile<<"BiGauss Threshold Value "<<BiGaussThrVal<<"\n";
	outFile1<<"BiGauss Threshold Value "<<BiGaussThrVal<<"\n";
	delete [] histAry;
	inFile1.close();
	inFile2.close();
	outFile1.close();
	deBugFile.close();
	return 0;
}
