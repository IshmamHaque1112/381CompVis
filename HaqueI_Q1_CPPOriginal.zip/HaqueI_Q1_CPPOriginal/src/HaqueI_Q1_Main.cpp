//============================================================================
// Name        : HaqueI_Q1_CPPOriginal.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <cmath>
#include <stdio.h>
#include <math.h>
#include <string>
#include <algorithm>
using namespace std;
int thrVal;
int numRows,numCols,minVal,maxVal;
int SobelVMask[9]={1,0,-1,2,0-2,1,0,-1};
int SobelHMask[9]={1,2,1,0,0,0,-1,-2,-1};
int SobelRMask[9]={2,1,0,1,0,-1,0,-1,-2};
int SobelLMask[9]={0,1,2,-1,0,1,-2,-1,0};
void loadImage(ifstream& inFile,int** zeroFramedAry){
  int row=1,col=1;
  int counter=0;
  string loaded="";
  while(inFile>>loaded) {
  	int currval=stoi(loaded);
  	zeroFramedAry[row][col]=currval;
  	counter++;
  	col++;
  	if(col==1+numCols){
  	 row=row+1;
  	 col=1;
  	}
  	if(counter==numRows*numCols) break;
  }
}
void binaryThreshold(int** Ary,int** thrAry,int thrVal){
  for(int i=0;i<numRows+2;i++){
   for(int j=0;j<numCols+2;j++){
	  thrAry[i][j]=0;
   }
  }
  for(int i=1;i<numRows+1;i++){
   for(int j=1;j<numCols+1;j++){
  	 if(Ary[i][j]<thrVal) thrAry[i][j]=0;
  	 if(Ary[i][j]>=thrVal) thrAry[i][j]=1;
   }
  }
}
void nonBinaryThreshold(int** Ary,int** thrAry,int thrVal){
  for(int i=0;i<numRows+2;i++){
   for(int j=0;j<numCols+2;j++){
	  thrAry[i][j]=0;
   }
  }
  for(int i=1;i<numRows+1;i++){
   for(int j=1;j<numCols+1;j++){
  	 if(Ary[i][j]<thrVal) thrAry[i][j]=0;
  	 if(Ary[i][j]>=thrVal) thrAry[i][j]=Ary[i][j];
   }
  }
}
void mirrorFraming(int** mirrorFramedAry){
  for(int i=0;i<numCols+2;i++){
	if(i==0){
	 mirrorFramedAry[0][i]=mirrorFramedAry[1][1];
	 mirrorFramedAry[numRows+1][i]=mirrorFramedAry[numRows+1][1];
	}
	else if(i==numCols+1){
		mirrorFramedAry[0][i]=mirrorFramedAry[1][numCols+1];
	    mirrorFramedAry[numRows+1][i]=mirrorFramedAry[numRows+1][numCols+1];
	}
	else{
	  mirrorFramedAry[0][i]=mirrorFramedAry[1][i];
	  //mirrorFramedAry[numRows+1][i]=mirrorFramedAry[numRows+1][i];
	}
  }
  for(int i=1;i<numRows+1;i++){
	mirrorFramedAry[i][0]=mirrorFramedAry[i][1];
	//mirrorFramedAry[i][numCols+1]=mirrorFramedAry[i][numCols+1];
  }
}
void imgReformat(int** inAry,ofstream& outFile){
	int newmax=0;
	int newmin=100000;
	for(int r=1;r<numRows+1;r++){
	 for(int c=1;c<numCols+1;c++){
	   if(newmax<inAry[r][c]) newmax=inAry[r][c];
	   if(newmin>inAry[r][c]) newmin=inAry[r][c];
	 }
	}
	outFile<<"Rows "<<numRows<<" Cols "<<numCols<<" minVal "<<newmin<<" maxVal "<<newmax<<"\n";
	string str=to_string(maxVal); // C++ build-in
	int Width=str.length();
	for(int r=1;r<numRows+1;r++){
	 for(int c=1;c<numCols+1;c++){
	  outFile<<inAry[r][c];
	  str=to_string(inAry[r][c]);
	  for(int WW=str.length()-1;WW<Width+1;WW++){
	    outFile<<" ";
	  }
	 }
	 outFile<<"\n";
	}
}
void loadNeighborAry(int** mirrorFramedAry,int i,int j,int* neighborAry){
 for(int i=0;i<9;i++) neighborAry[i]=0;
 int counter=0;
 for(int a=i-1;a<=i+1;a++){
  for(int b=j-1;b<=j+1;b++){
	neighborAry[counter]=mirrorFramedAry[a][b];
	counter++;
  }
 }
 //for(int i=0;i<25;i++) cout<<neighborAry[i];
}
int convolution(int* neighborAry,int* maskAry){
 int result=0;
 for(int i=0;i<9;i++){
	result += neighborAry[i] * maskAry[i];
 }
 return result;
}
void SobelEdgeDetector(int** mirrorFramedAry,int** SobelEdgeAry,ofstream& deBugFile){
	deBugFile <<"entering SobelEdgeDetector method "<<"\n";
	for(int i=1;i<numRows+1;i++){
	 for(int j=1;j<numCols+1;j++){
		 int NeighborAry[9];
		 loadNeighborAry(mirrorFramedAry,i,j,NeighborAry);
		 int tmpV=abs(convolution(NeighborAry,SobelVMask));
		 int tmpH=abs(convolution(NeighborAry,SobelHMask));
		 int tmpR=abs(convolution(NeighborAry,SobelRMask));
		 int tmpL=abs(convolution(NeighborAry,SobelLMask));
		 int total=tmpV+tmpH+tmpR+tmpL;
		 SobelEdgeAry[i][j]=total/2;
	 }
	}
}
int main(int argc,char** argv) {
    cout<<"Hello"<<endl;
	ifstream inFile;
	inFile.open(argv[1]);
    cout<<"Hello"<<endl;
	thrVal=atoi(argv[2]);
	ofstream SobelEdgeFile,deBugFile;
	SobelEdgeFile.open(argv[3]);
	deBugFile.open(argv[4]);
	int numberindex1=0,numberindex2=0;
	string currentst1="";
	while(inFile>>currentst1) {
	  numberindex1++;
	  int currval1= stoi(currentst1);
	  if(numberindex1==1) numRows=currval1;
	  if(numberindex1==2) numCols=currval1;
	  if(numberindex1==3) minVal=currval1;
	  if(numberindex1==4) {
		maxVal=currval1;
		break;
	  }
    }
	int **mirrorFramedAry = (int **) malloc(sizeof(int*) * (numRows+2));
    int **SobelEdgeAry = (int **) malloc(sizeof(int*) * (numRows+2));
    int **thrAry = (int **) malloc(sizeof(int*) * (numRows+2));
    for(int i = 0; i < numRows+2; i++){
	  mirrorFramedAry[i] = (int *) malloc(sizeof(int) * (numCols+2));
	  SobelEdgeAry[i] = (int *) malloc(sizeof(int) * (numCols+2));
	  thrAry[i] = (int *) malloc(sizeof(int) * (numCols+2));
	}
    loadImage(inFile,mirrorFramedAry);
    mirrorFraming(mirrorFramedAry);
    deBugFile<<"Mirrored image"<<endl;
    imgReformat(mirrorFramedAry,deBugFile);
    SobelEdgeDetector(mirrorFramedAry,SobelEdgeAry,deBugFile);
    SobelEdgeFile<<"SobelEdgeDetector Image"<<endl;
    imgReformat(SobelEdgeAry,SobelEdgeFile);
    SobelEdgeFile<<"Non-binary SobelEdgeDetector Image"<<endl;
    nonBinaryThreshold(SobelEdgeAry,thrAry,thrVal);
    imgReformat(thrAry,SobelEdgeFile);
    SobelEdgeFile<<"Binary SobelEdgeDetector Image"<<endl;
    binaryThreshold(SobelEdgeAry,thrAry,thrVal);
    imgReformat(thrAry,SobelEdgeFile);
    deBugFile<<"Leaving SobelEdgeDetector method"<<endl;
    //cout<<"Hello"<<endl;
    inFile.close();
    SobelEdgeFile.close();
    deBugFile.close();
	return 0;
}
