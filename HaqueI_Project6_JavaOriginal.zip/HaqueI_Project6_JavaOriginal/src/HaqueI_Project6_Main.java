import java.io.*;
import java.util.*;
public class HaqueI_Project6_Main {
	static int numRows, numCols, minVal, maxVal,offSet;
	static int[][] imgAry=null;
	static int[][] CartesianHoughAry=null;
	static int[][] PolarHoughAry=null;		
	static void loadImage(Scanner imgFile,int[][] imgAry) {
		  for(int i=0;i<numRows;i++) {
			for(int j=0;j<numCols;j++) {
				if(imgFile.hasNext()) {
				 int currval= Integer.parseInt(imgFile.next());
				 imgAry[i][j]=currval;
				}
			}
		  } 
	 }
	static void setzeroAry(int[][] imgAry, int rowSize, int colSize) {
		  for(int i=0;i<rowSize;i++) {
			for(int j=0;j<colSize;j++) {
			 imgAry[i][j]=0;	
			}  
		  } 
	}
	static void prettyPrint(int[][] zeroFramedAry,BufferedWriter outFile1, int r1,int c1) throws IOException{
		int newmax=0;
		int newmin=100000;
		for(int i=0;i<r1;i++) {
			for(int j=0;j<c1;j++) {
		   if(newmax<zeroFramedAry[i][j]) newmax=zeroFramedAry[i][j];
		   if(newmin>zeroFramedAry[i][j]) newmin=zeroFramedAry[i][j];
		 }
		}
		outFile1.write(Integer.toString(numRows)+" "+Integer.toString(numCols)+" "+Integer.toString(newmin)+" "+Integer.toString(newmax));
		outFile1.newLine();
		String str=String.valueOf(newmax);
		int Width=str.length();
		for(int r=0;r<r1;r++){
		 for(int c=0;c<c1;c++){
		    //outFile1.write(Integer.toString(zeroFramedAry[r][c]));
		  if(zeroFramedAry[r][c]!=0) outFile1.write(Integer.toString(zeroFramedAry[r][c]));
		  if(zeroFramedAry[r][c]==0) outFile1.write(".");
		  str=String.valueOf(zeroFramedAry[r][c]);
		  for(int WW=str.length()-1;WW<Width+1;WW++){
			 outFile1.write(" ");
		  }
		 }
		 outFile1.newLine();
		}	
	}
	static double CartesianDist(int x,int y,double angleInRadians) {
	  double Radians90= (double) ((90.0* Math.PI)/ (180.00));
	  double t=(double) (angleInRadians- Math.atan((y*1.0)/(x*1.0))- Radians90); 
	  double result=Math.sqrt((x*x*1.0)+(y*y*1.0))*Math.cos(t);
	  result=result+offSet;
	  return result;
		
	}
	static double PolarDist(int x,int y,double angleInRadians) {
		  double doublex=x*1.0;
		  double doubley=y*1.0;
		  double result=(doublex*Math.cos(angleInRadians))+(doubley*Math.sin(angleInRadians));
		  result=result+offSet;
		  return result;
			
	}
	static void computeSinusoid(int x,int y) {
	 for(int angleInDegree=0;angleInDegree<=179;angleInDegree++) {
	  double angleInRadians= (double) ((angleInDegree* Math.PI)/ (180.00));
	  double dist=CartesianDist(x, y, angleInRadians);
	  //System.out.println(dist);
	  int distInt=(int) dist; // cast dist from double to int
	  CartesianHoughAry[distInt][angleInDegree]++;
	  dist=PolarDist(x, y, angleInRadians);
	  //System.out.println(dist);
	  distInt=(int) dist; // cast dist from double to int
	  PolarHoughAry[distInt][angleInDegree]++;
	 }
	}
	static void buildHoughSpace() {
	 for(int x=0;x<numRows;x++) {
	  for(int y=0;y<numCols;y++) {
		  if(imgAry[x][y]>0) computeSinusoid(x,y);
	  }
	 }

	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner inFile= new Scanner(new FileReader(args[0]));
		BufferedWriter outFile1=new BufferedWriter(new FileWriter(args[1]));
		int numberindex1=0;
		int numberindex2=0;
		while(inFile.hasNext()) {
			numberindex1++;
			int currval= Integer.parseInt(inFile.next());
		    if(numberindex1==1) numRows=currval;
		    if(numberindex1==2) numCols=currval;
		    if(numberindex1==3) minVal=currval;
		    if(numberindex1==4) {
		      maxVal=currval;
		      break;
		    }  
		}
		offSet=(int) Math.sqrt((numRows*numRows*1.0)+(numCols*numCols*1.0));
		int HoughAngle=180;
		int HoughDist=2*offSet;
		imgAry= new int[numRows][numCols]; 
		setzeroAry(imgAry,numRows,numCols);
	    CartesianHoughAry=new int[HoughDist][HoughAngle];
		setzeroAry(CartesianHoughAry,HoughDist,HoughAngle);
		PolarHoughAry=new int[HoughDist][HoughAngle];
		setzeroAry(PolarHoughAry,HoughDist,HoughAngle);
		loadImage(inFile, imgAry);
		prettyPrint(imgAry, outFile1,numRows,numCols);
		buildHoughSpace();
		outFile1.write("Cartesian: \n");
		prettyPrint(CartesianHoughAry, outFile1,HoughDist,HoughAngle); // with caption indicate it is Cartesian Hough space
		outFile1.write("Polar: \n");
		prettyPrint(PolarHoughAry, outFile1,HoughDist,HoughAngle); // with caption indicate it is Polar Hough space
        inFile.close();
        outFile1.close();

	}

}