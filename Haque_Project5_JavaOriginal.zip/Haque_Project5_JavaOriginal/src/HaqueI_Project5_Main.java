import java.io.*;
import java.util.*;
public class HaqueI_Project5_Main {
	static int numRows=0, numCols=0, minVal=0, maxVal=0;
	static int newMinVal=0,newMaxVal=0,distMinVal=100000, distMaxVal=0;
	static ArrayList<Integer> intr = new ArrayList<Integer>();
	static ArrayList<Integer> intc = new ArrayList<Integer>();
	static ArrayList<Integer> intval = new ArrayList<Integer>();
	static void setzeroAry(int[][] zeroFramedAry, int rowSize, int colSize) {
		  for(int i=0;i<rowSize;i++) {
			for(int j=0;j<colSize;j++) {
			 zeroFramedAry[i][j]=0;	
			}  
		  } 
	}
	static void loadImage(Scanner imgFile,int[][] zeroFramedAry) {
		  for(int i=1;i<numRows+1;i++) {
			for(int j=1;j<numCols+1;j++) {
				if(imgFile.hasNext()) {
				 int currval= Integer.parseInt(imgFile.next());
				 zeroFramedAry[i][j]=currval;
				}
			}
		  } 
	   }
	static void reformatPrettyPrint(int[][] zeroFramedAry,BufferedWriter outFile1) throws IOException{
		int newmax=0;
		int newmin=100000;
		for(int i=1;i<numRows+1;i++) {
			for(int j=1;j<numCols+1;j++) {
		   if(newmax<zeroFramedAry[i][j]) newmax=zeroFramedAry[i][j];
		   if(newmin>zeroFramedAry[i][j]) newmin=zeroFramedAry[i][j];
		 }
		}
		outFile1.write(Integer.toString(numRows)+" "+Integer.toString(numCols)+" "+Integer.toString(newmin)+" "+Integer.toString(newmax));
		outFile1.newLine();
		String str=String.valueOf(newmax);
		int Width=str.length();
		for(int r=1;r<numRows+1;r++){
		 for(int c=1;c<numCols+1;c++){
		    outFile1.write(Integer.toString(zeroFramedAry[r][c]));
		  //if(zeroFramedAry[r][c]!=0) outFile1.write(zeroFramedAry[r][c]);
		  //if(zeroFramedAry[r][c]==0) outFile1.write(".");
		  str=String.valueOf(zeroFramedAry[r][c]);
		  for(int WW=str.length()-1;WW<Width+1;WW++){
			 outFile1.write(" ");
		  }
		 }
		 outFile1.newLine();
		}	
	}
	static void binaryThreshold(int[][] inAry,BufferedWriter outFile1) throws IOException{
		  for(int i=1;i<numRows+1;i++){
		   for(int j=1;j<numCols+1;j++){
			 if(inAry[i][j]>=1) outFile1.write("1 ");
		  	 if(inAry[i][j]==0) outFile1.write("0 ");
		   }
		   outFile1.newLine();
		  }
	}
	static void Distance8Pass1(int[][] zeroFramedAry) {
		for(int r=1;r<numRows+1;r++){
			 for(int c=1;c<numCols+1;c++){
			  if(zeroFramedAry[r][c]>0){
				ArrayList<Integer> intarr = new ArrayList<Integer>();
				intarr.add(zeroFramedAry[r-1][c-1]);
				intarr.add(zeroFramedAry[r-1][c]);
				intarr.add(zeroFramedAry[r-1][c+1]);
				intarr.add(zeroFramedAry[r][c-1]);
				zeroFramedAry[r][c]=Collections.min(intarr)+1;
			  }
			 }
			}
	}
	static void Distance8Pass2(int[][] zeroFramedAry) {
		for(int r=numRows;1<=r;r--){
			 for(int c=numCols;1<=c;c--){
			  if(zeroFramedAry[r][c]>0){
				ArrayList<Integer> intarr = new ArrayList<Integer>();
				intarr.add(zeroFramedAry[r][c+1]+1);
				intarr.add(zeroFramedAry[r+1][c-1]+1);
				intarr.add(zeroFramedAry[r+1][c]+1);
				intarr.add(zeroFramedAry[r+1][c+1]+1);
				intarr.add(zeroFramedAry[r][c]);
				zeroFramedAry[r][c]=Collections.min(intarr);
			  }
			 }
			}
	}
	static void Distance8(int[][] zeroFramedAry,BufferedWriter outFile1,BufferedWriter deBugFile) throws IOException{
	 deBugFile.write("Entering Distance8");
	 deBugFile.newLine();
	 Distance8Pass1(zeroFramedAry);
	 outFile1.write("Distance Pass 1");
	 outFile1.newLine();
	 reformatPrettyPrint(zeroFramedAry, outFile1);
	 Distance8Pass2(zeroFramedAry);
	 outFile1.write("Distance Pass 2");
	 outFile1.newLine();
	 reformatPrettyPrint(zeroFramedAry, outFile1);
	 for(int i=1;i<numRows+1;i++) {
	   for(int j=1;j<numCols+1;j++) {
		   if(distMaxVal<zeroFramedAry[i][j]) distMaxVal=zeroFramedAry[i][j];
		   if(distMinVal>zeroFramedAry[i][j]) distMinVal=zeroFramedAry[i][j];
	  }
	}
	 deBugFile.write("Leaving Distance8");
	 deBugFile.newLine();
	}
	static void localMaxima(int[][] zeroFramedAry,int[][] skeletonAry) {
		for(int r=1;r<numRows+1;r++){
			 for(int c=1;c<numCols+1;c++){
				ArrayList<Integer> intarr = new ArrayList<Integer>();
				intarr.add(zeroFramedAry[r-1][c-1]);
				intarr.add(zeroFramedAry[r-1][c]);
				intarr.add(zeroFramedAry[r-1][c+1]);
				intarr.add(zeroFramedAry[r][c-1]);
				intarr.add(zeroFramedAry[r][c+1]);
				intarr.add(zeroFramedAry[r+1][c-1]);
				intarr.add(zeroFramedAry[r+1][c]);
				intarr.add(zeroFramedAry[r+1][c+1]);
				int maxval=Collections.max(intarr);
				if(zeroFramedAry[r][c]>=maxval) skeletonAry[r][c]=zeroFramedAry[r][c];
				else skeletonAry[r][c]=0;
			 }
			}
	}
    static void compression(int[][] skeletonAry,BufferedWriter skeletonFile) throws IOException {
    	for(int r=1;r<numRows+1;r++){
			 for(int c=1;c<numCols+1;c++){
				 if(skeletonAry[r][c]>0) {
					 skeletonFile.write(r+" "+c+" "+Integer.toString(skeletonAry[r][c]));
				     intr.add(r);
				     intc.add(c);
				     intval.add(skeletonAry[r][c]);
					 skeletonFile.newLine();
				 }
			 
			 }	
		 }
    }
	static void skeletonExtraction(int[][] zeroFramedAry,int[][] skeletonAry,BufferedWriter skeletonFile,BufferedWriter outFile1,BufferedWriter deBugFile) throws IOException {
	 deBugFile.write("Entering skeletonExtraction");
	 deBugFile.newLine();
	 localMaxima(zeroFramedAry, skeletonAry);
	 outFile1.write("Uncompressed maxima skeleton");
	 outFile1.newLine();
	 reformatPrettyPrint(skeletonAry, outFile1);
	 // with proper caption i.e., Local maxima
	 reformatPrettyPrint(skeletonAry,skeletonFile);
	 compression(skeletonAry,skeletonFile);
	 skeletonFile.close();
	 deBugFile.write("Leaving skeletonExtraction");
	 deBugFile.newLine();
	}
	static void expansion8Pass1(int[][] zeroFramedAry) {
		for(int r=1;r<numRows+1;r++){
			 for(int c=1;c<numCols+1;c++){
			  if(zeroFramedAry[r][c]==0){
				ArrayList<Integer> intarr = new ArrayList<Integer>();
				intarr.add(zeroFramedAry[r-1][c-1]-1);
				intarr.add(zeroFramedAry[r-1][c]-1);
				intarr.add(zeroFramedAry[r-1][c+1]-1);
				intarr.add(zeroFramedAry[r][c-1]-1);
				intarr.add(zeroFramedAry[r][c+1]-1);
				intarr.add(zeroFramedAry[r+1][c-1]-1);
				intarr.add(zeroFramedAry[r+1][c]-1);
				intarr.add(zeroFramedAry[r+1][c+1]-1);
				intarr.add(zeroFramedAry[r][c]);
				zeroFramedAry[r][c]=Collections.max(intarr);
			  }
			 }
		 }
	}
	static void expansion8Pass2(int[][] zeroFramedAry) {
		for(int r=numRows;0<r;r--){
			 for(int c=numCols;0<c;c--){
				ArrayList<Integer> intarr = new ArrayList<Integer>();
				intarr.add(zeroFramedAry[r-1][c-1]-1);
				intarr.add(zeroFramedAry[r-1][c]-1);
				intarr.add(zeroFramedAry[r-1][c+1]-1);
				intarr.add(zeroFramedAry[r][c-1]-1);
				intarr.add(zeroFramedAry[r][c+1]-1);
				intarr.add(zeroFramedAry[r+1][c-1]-1);
				intarr.add(zeroFramedAry[r+1][c]-1);
				intarr.add(zeroFramedAry[r+1][c+1]-1);
				intarr.add(zeroFramedAry[r][c]);
				if(zeroFramedAry[r][c]<Collections.max(intarr))zeroFramedAry[r][c]=Collections.max(intarr);
			 }
		 }
	}
	static void deCompression(int[][] zeroFramedAry,Scanner skeletonFile,BufferedWriter outFile2,BufferedWriter deBugFile) throws IOException {
	 deBugFile.write("Entering deCompression method");
	 deBugFile.newLine();
	 setzeroAry(zeroFramedAry,numRows+2,numCols+2);
	 loadImage(skeletonFile, zeroFramedAry);
	 expansion8Pass1(zeroFramedAry);
	 outFile2.write("Expansion Pass 1");
	 outFile2.newLine();
	 reformatPrettyPrint(zeroFramedAry, outFile2);
	 // with proper caption i.e., 1st pass Expansion
	 expansion8Pass2(zeroFramedAry); // begins at ZeroFramedAry(?,?)
	 // During the 2nd pass, you need to track the newMinVal and newMaxVal
	 outFile2.write("Expansion Pass 2");
	 outFile2.newLine();
	 reformatPrettyPrint(zeroFramedAry, outFile2);
	 // with proper caption i.e., 2nd pass Expansion
	 deBugFile.write("Leaving deCompression method");
	 deBugFile.newLine();

	}
	static void ary2File(int[][] zeroFramedAry,BufferedWriter decompressFile) throws IOException{
		String str=String.valueOf(maxVal);
		int Width=str.length();
		for(int r=1;r<numRows+1;r++){
		 for(int c=1;c<numCols+1;c++){
			 decompressFile.write(Integer.toString(zeroFramedAry[r][c]));
		  //if(zeroFramedAry[r][c]!=0) outFile1.write(zeroFramedAry[r][c]);
		  //if(zeroFramedAry[r][c]==0) outFile1.write(".");
		  str=String.valueOf(zeroFramedAry[r][c]);
		  for(int WW=str.length()-1;WW<Width+1;WW++){
		  decompressFile.write(" ");
		  }
		 }
		 decompressFile.newLine();
		}	
	}

	public static void main(String[] args) throws IOException {
		Scanner inFile= new Scanner(new FileReader(args[0]));
		BufferedWriter outFile1=new BufferedWriter(new FileWriter(args[1]));
		BufferedWriter outFile2=new BufferedWriter(new FileWriter(args[2]));
		BufferedWriter deBugFile=new BufferedWriter(new FileWriter(args[3]));
		 deBugFile.write("Entering deCompression method");
		int numberindex1=0;
		int numberindex2=0;
		while(inFile.hasNext()) {
			numberindex1++;
			int currval= Integer.parseInt(inFile.next());
		    if(numberindex1==1) numRows=currval;
		    if(numberindex1==2) numCols=currval;
		    if(numberindex1==3) minVal=currval;
		    if(numberindex1==4) {
		      maxVal=currval;
		      break;
		    }  
		}
		int[][] zeroFramedAry= new int[numRows+2][numCols+2]; 
		int[][] skeletonAry= new int[numRows+2][numCols+2];
		String skeletonFileName=args[0] + "_skeleton.txt";
		String decompressedFileName=args[0] + "_decompressed.txt";
		File skeletonFile1=new File(skeletonFileName);
		File decompressFile1=new File(decompressedFileName);
		setzeroAry(zeroFramedAry,numRows+2,numCols+2);
		setzeroAry(skeletonAry,numRows+2,numCols+2);
		BufferedWriter skeletonFile=new BufferedWriter(new FileWriter(skeletonFile1));
		BufferedWriter decompressFile=new BufferedWriter(new FileWriter(decompressFile1));
		loadImage(inFile,zeroFramedAry);
		Distance8(zeroFramedAry, outFile1, deBugFile); // Perform distance transform
		int[][] zero2=new int[numRows+2][numCols+2];
		for(int i=0;i<numRows+2;i++) {
		 for(int j=0;j<numCols+2;j++) {
			zero2[i][j]=zeroFramedAry[i][j]; 
		 }
		}
		skeletonExtraction(zeroFramedAry, skeletonAry, skeletonFile, outFile1, deBugFile);
		// perform lossless compression
		Scanner skeletonFileread=new Scanner(new FileReader(skeletonFile1));
		while(skeletonFileread.hasNext()) {
			numberindex2++;
			skeletonFileread.next();
		    if(numberindex2==4) {
		      break;
		    }  
		}
		deCompression(zeroFramedAry, skeletonFileread, outFile2, deBugFile);
		// perform decompression
		outFile2.write(Integer.toString(numRows)+" "+Integer.toString(numCols)+" "+Integer.toString(distMinVal)+" "+Integer.toString(distMaxVal));
		outFile2.newLine();
		for(int i=0;i<intr.size();i++) {
		 outFile2.write(Integer.toString(intr.get(i))+" "+Integer.toString(intc.get(i))+" "+Integer.toString(intval.get(i)));
		 outFile2.newLine();
		}
		//binaryThreshold(zeroFramedAry,decompressFile);
		int newmax=0;
		int newmin=100000;
		int nmax=0;
		int nmin=0;
		for(int i=1;i<numRows+1;i++) {
			for(int j=1;j<numCols+1;j++) {
		   if(newmax<zeroFramedAry[i][j]) newmax=zeroFramedAry[i][j];
		   if(newmin>zeroFramedAry[i][j]) newmin=zeroFramedAry[i][j];
		 }
		}
		if(newmax>0) nmax=1;
		else nmax=0;
		if(newmin>0) nmin=1;
		else nmin=0;
		decompressFile.write(Integer.toString(numRows)+" "+Integer.toString(numCols)+" "+Integer.toString(nmin)+" "+Integer.toString(nmax));
		decompressFile.newLine();
		binaryThreshold(zeroFramedAry, decompressFile);
		outFile2.write(Integer.toString(numRows)+" "+Integer.toString(numCols)+" "+Integer.toString(nmin)+" "+Integer.toString(nmax));
		outFile2.newLine();
		binaryThreshold(zeroFramedAry, outFile2);
		decompressFile.close();
		inFile.close();
		skeletonFileread.close();
		outFile1.close();
		outFile2.close();
		deBugFile.close();


	}

}

