import java.io.*;
import java.util.*;
public class HaqueI_Q2_Main {
    static int numRows,numCols,numPts;
	static int K;
	static Scanner inFile;
	static BufferedWriter dispFile,clusterFile,deBugFile;
	static int[][] displayAry;
	static void prettyPrint(int[][] zeroFramedAry,BufferedWriter outFile, int iteration) throws IOException{
		outFile.write("K= "+iteration);
		outFile.newLine();
		for(int r=0;r<numRows;r++){
		 for(int c=0;c<numCols;c++){
		  if(zeroFramedAry[r][c]>0) outFile.write(Integer.toString(zeroFramedAry[r][c])+" ");
		  else outFile.write("  ");
		 }
		 outFile.newLine();
		}	
	}
	static void partition(int[] pointSetx,int[] pointSety,int[] pointSetlabel,double[] pointSetdistance,int K) {
		int label=1;
		for(int index=0;index<numPts;index++) {
			pointSetlabel[index]=label;
			//System.out.println(label);
			label=label+1;
			if(label==K+1) label=1;
		}
	}
	static void computeCentroid(int[] pointSetx,int[] pointSety,int[] pointSetlabel,double[] pointSetdistance,int K,int[] KcentroidAryx,int[] KcentroidAryy,int[] KcentroidArylabel,double[] KcentroidArydistance,BufferedWriter deBugFile) throws IOException {
		deBugFile.write("Entering computeCentroid");
		deBugFile.newLine();
		for(int Klabel=1;Klabel<K+1;Klabel++) {
			double sumX=0.0,sumY=0.0;
			int totalPt=0;
			for(int index=0;index<numPts;index++) {
			 if(pointSetlabel[index]==Klabel) {
				sumX=sumX+((double) pointSetx[index]);
				sumY=sumY+((double) pointSety[index]);
				totalPt++;
			 }	
			}
			if(totalPt>0) {
			 KcentroidAryx[Klabel]=(int) (sumX/totalPt);
			 KcentroidAryy[Klabel]=(int) (sumY/totalPt);
			 //System.out.println(KcentroidAryx[Klabel]);
			 //System.out.println(KcentroidAryy[Klabel]);
			}
		}
		deBugFile.write("Leaving computeCentroid");
		deBugFile.newLine();
	}
	static int relabel(int[] pointSetx,int[] pointSety,int[] pointSetlabel,double[] pointSetdistance,int K,int[] KcentroidAryx,int[] KcentroidAryy,int[] KcentroidArylabel,double[] KcentroidArydistance) throws IOException {
		deBugFile.write("Entering relabel method \n");
		int change=0;
		double x1,x2,y1,y2,dx,dy,dist;
		for(int index=0;index<numPts;index++) {
			double minDist=pointSetdistance[index];
			int minLabel=1;
			ArrayList<Double> distarr=new ArrayList<Double>();
			ArrayList<Double> distarr1=new ArrayList<Double>();
			for(int label=1;label<K+1;label++) {
				 x1=(double) KcentroidAryx[label];
				 y1=(double) KcentroidAryy[label];	
				 x2=(double) pointSetx[index];	
				 y2=(double) pointSety[index];	
	             dx=(x1-x2)*(x1-x2);
	             dy=(y1-y2)*(y1-y2);
	             dist=(double) Math.sqrt(dx+dy);
	             distarr.add(dist);
	             distarr1.add(dist);
			}
			Collections.sort(distarr1);
			System.out.println(distarr);
		    minDist=distarr1.get(0);
			for(int i=0;i<distarr.size();i++) {
				if(distarr.get(i)==minDist) {
					minLabel=i+1;
				}
			}
			//System.out.println(distarr+" "+index);
			//for(int label=1;label<K+1;label++) {
			// x1=(double) KcentroidAryx[label];
			// y1=(double) KcentroidAryy[label];	
			// x2=(double) pointSetx[label];	
			// y2=(double) pointSety[label];	
            // dx=(x1-x2)*(x1-x2);
            // dy=(y1-y2)*(y1-y2);
            // dist=(double) Math.sqrt(dx+dy);
            // if(dist<minDist) {
            //  minLabel=label;
            //  minDist=dist;
            // }
			//}
			//System.out.println(pointSetdistance[index]);
			if(pointSetlabel[index]!=minLabel) {
			 //System.out.println(index);
			 pointSetlabel[index]=minLabel;
			 pointSetdistance[index]=minDist;
			 change++;
			}
		}
		deBugFile.write("change= "+change+"\n");
		deBugFile.write("Leaving relabel method \n");
		return change;

	}
	static void loadPointSet(Scanner inFile,int[] pointSetx,int[] pointSety) {
	 for(int i=0;i<numPts;i++) {
		if(inFile.hasNext()) {
			pointSetx[i]= Integer.parseInt(inFile.next());	 
		}
		if(inFile.hasNext()) {
			pointSety[i]= Integer.parseInt(inFile.next());	 
		}
	 }	
	}
	static void printPointSet(int[] pointSetx,int[] pointSety,int[] pointSetlabel,double[] pointSetdistance,BufferedWriter clusterFile) throws IOException {
	 for(int i=0;i<numPts;i++) {
	  clusterFile.write(Integer.toString(pointSetx[i])+" "+Integer.toString(pointSety[i])+" "+Integer.toString(pointSetlabel[i])+" "+Double.toString(pointSetdistance[i])+"\n");	 
	 }
	}
	static void plotDisplayAry(int[] pointSetx,int[] pointSety,int[] pointSetlabel,double[] pointSetdistance,int[][] displayAry) {
		for(int i=0;i<numRows;i++) {
		 for(int j=0;j<numCols;j++) {
			displayAry[i][j]=0; 
		 }
		}
		for(int i=0;i<numPts;i++) {
		  displayAry[pointSetx[i]][pointSety[i]]=pointSetlabel[i];	
		}
	}
	static void kMeansClustering(int[] pointSetx,int[] pointSety,int[] pointSetlabel,double[] pointSetdistance,int K,int[] KcentroidAryx,int[] KcentroidAryy,int[] KcentroidArylabel,double[] KcentroidArydistance,BufferedWriter deBugFile) throws IOException {
		deBugFile.write("Entering kMeansClustering method \n");
		int iteration=0;
		partition(pointSetx,pointSety,pointSetlabel,pointSetdistance,K);
		int numChange=5;
		while(numChange>2) {
		 computeCentroid(pointSetx,pointSety,pointSetlabel,pointSetdistance,K,KcentroidAryx,KcentroidAryy,KcentroidArylabel,KcentroidArydistance,deBugFile);
		 plotDisplayAry(pointSetx,pointSety,pointSetlabel,pointSetdistance,displayAry);
		 prettyPrint(displayAry,dispFile,iteration);
		 numChange=relabel(pointSetx,pointSety,pointSetlabel,pointSetdistance,K,KcentroidAryx,KcentroidAryy,KcentroidArylabel,KcentroidArydistance);
		 iteration++;
		}
		deBugFile.write("Leaving kMeansClustering method \n");

	}

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		inFile= new Scanner(new FileReader(args[0]));
		K=Integer.parseInt(args[1]);
		System.out.println(K);
		dispFile=new BufferedWriter(new FileWriter(args[2]));
		clusterFile=new BufferedWriter(new FileWriter(args[3]));
		deBugFile=new BufferedWriter(new FileWriter(args[4]));
		int numberindex1=0;
		while(inFile.hasNext()) {
			numberindex1++;
			int currval= Integer.parseInt(inFile.next());
		    if(numberindex1==1) numRows=currval;
		    if(numberindex1==2) numCols=currval;
		    if(numberindex1==3) {
		      numPts=currval;
		      break;
		    }  
		}
		displayAry=new int[numRows][numCols];
		int[] pointSetx=new int[numPts];
		int[] pointSety=new int[numPts];
		int[] pointSetlabel=new int[numPts];
		double[] pointSetdistance=new double[numPts];
		for(int i=0;i<numPts;i++) {
		 pointSetdistance[i]=9999999.0;
		}
		int[] KcentroidAryx=new int[K+1];
		int[] KcentroidAryy=new int[K+1];
		int[] KcentroidArylabel=new int[K+1];
		double[] KcentroidArydistance=new double[K+1];
		loadPointSet(inFile,pointSetx,pointSety);
		kMeansClustering(pointSetx,pointSety,pointSetlabel,pointSetdistance,K,KcentroidAryx,KcentroidAryy,KcentroidArylabel,KcentroidArydistance,deBugFile);
		clusterFile.write(numRows+" "+numCols+" "+numPts+"\n");
		printPointSet(pointSetx,pointSety,pointSetlabel,pointSetdistance,clusterFile);
		
		
		
		inFile.close();
		dispFile.close();
		clusterFile.close();
		deBugFile.close();
	}

}
