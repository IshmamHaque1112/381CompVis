import java.io.*;
import java.util.*;
public class HaqueI_Project01_Main {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		int numRows=0, numCols=0, minVal=0, maxVal=0,thrValue=0;
		BufferedWriter outFile2=new BufferedWriter(new FileWriter(args[2]));
		System.out.println("Input your threshold number");
		outFile2.write("Input your threshold number");
		outFile2.newLine();
		int inItem, outItem;
		Scanner in = new Scanner(System.in);
		inItem=in.nextInt();
		thrValue=inItem;
		System.out.println("The threshold value is "+ thrValue);
		outFile2.write("The threshold value is "+ thrValue);
		outFile2.newLine();
		Scanner inFile1= new Scanner(new FileReader(args[0]));
		BufferedWriter outFile1=new BufferedWriter(new FileWriter(args[1]));
		int numberindex=0;
		while(inFile1.hasNext()) {
			numberindex++;
			int currval= Integer.parseInt(inFile1.next());
		    if(numberindex==1) numRows=currval;
		    if(numberindex==2) numCols=currval;
		    if(numberindex==3) minVal=currval;
		    if(numberindex==4) {
		      maxVal=currval;
		      break;
		    }  
		}
		int rownum=1;
		int colnum=0;
		int newmin=0;
		int newmax=0;
		String currstring="";
		if(minVal<thrValue) newmin=0;
		if(minVal>=thrValue) newmin=1;
		if(maxVal<thrValue) newmax=0;
		if(maxVal>=thrValue) newmax=1;
		outFile1.write(numRows+" "+numCols+" "+newmin+" "+newmax);
		outFile1.newLine();
		while(inFile1.hasNext()) {
		  numberindex++;
		  colnum++;
		  int currval= Integer.parseInt(inFile1.next());
		  if(currval<thrValue) currstring=currstring+"0 ";
		  else if(currval>=thrValue) currstring=currstring+"1 ";
		  if(colnum==numCols) {
			outFile1.write(currstring);
			outFile1.newLine();
			currstring="";
			if(rownum==numRows) break;
			rownum++;
			colnum=0;
		 }
		}
		in.close();
		inFile1.close();
		outFile1.close();
		outFile2.close();
	}

}
