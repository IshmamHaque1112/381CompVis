//============================================================================
// Name        : HaqueI_Project2_Main.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <cmath>
#include <stdio.h>
#include <math.h>
#include <string>
using namespace std;
int numRows, numCols, minVal, maxVal,maskRows, maskCols, maskMin, maskMax;
int thr;
int *neighborAry = (int *) malloc(sizeof(int) * (5*5));
int *maskAry = (int *) malloc(sizeof(int) * (5*5));
int maskWeight=0; // The total value of the mask, to be computed in loadMask1DAry method.
void loadMaskAry(ifstream& maskFile,int* maskAry){
  int counter=0;
  string loaded="";
  while(maskFile>>loaded) {
  	int currval=stoi(loaded);
  	maskWeight=maskWeight+currval;
  	maskAry[counter]=currval;
  	counter++;
  	if(counter==maskRows*maskCols) break;
  }
}
void loadImage(ifstream& inFile,int** mirrorFramedAry){
  for(int i=0;i<numRows+4;i++){
	for(int j=0;j<numCols+4;j++){
	  mirrorFramedAry[i][j]=0;
	}
  }
  int row=2,col=2;
  int counter=0;
  string loaded="";
  while(inFile>>loaded) {
  	int currval=stoi(loaded);
  	mirrorFramedAry[row][col]=currval;
  	counter++;
  	col++;
  	if(col==2+numCols){
  	 row=row+1;
  	 col=2;
  	}
  	if(counter==numRows*numCols) break;
  }
}
void mirrorFraming(int** mirrorFramedAry){
 /*for(int i=0;i<numRows+4;i++){
    for(int j=0;j<numCols+4;j++){
       cout<<mirrorFramedAry[i][j]<<" ";
     }
    cout<<endl;
  }
 cout<<endl;*/
  for(int i=0;i<numCols+4;i++){
	if((i==0)||(i==1)){
	 mirrorFramedAry[0][i]=mirrorFramedAry[2][2];
	 mirrorFramedAry[1][i]=mirrorFramedAry[2][2];
	 mirrorFramedAry[numRows+2][i]=mirrorFramedAry[numRows+1][2];
	 mirrorFramedAry[numRows+3][i]=mirrorFramedAry[numRows+1][2];
	}
	else if((i==numCols+2)||(i==numCols+3)){
		mirrorFramedAry[0][i]=mirrorFramedAry[2][numCols+1];
	    mirrorFramedAry[1][i]=mirrorFramedAry[2][numCols+1];
	    mirrorFramedAry[numRows+2][i]=mirrorFramedAry[numRows+1][numCols+1];
	    mirrorFramedAry[numRows+3][i]=mirrorFramedAry[numRows+1][numCols+1];
	}
	else{
	  mirrorFramedAry[0][i]=mirrorFramedAry[2][i];
	  mirrorFramedAry[1][i]=mirrorFramedAry[2][i];
	  mirrorFramedAry[numRows+2][i]=mirrorFramedAry[numRows+1][i];
	  mirrorFramedAry[numRows+3][i]=mirrorFramedAry[numRows+1][i];
	}
  }
  for(int i=2;i<numRows+2;i++){
	mirrorFramedAry[i][0]=mirrorFramedAry[i][2];
	mirrorFramedAry[i][1]=mirrorFramedAry[i][2];
	mirrorFramedAry[i][numCols+2]=mirrorFramedAry[i][numCols+1];
	mirrorFramedAry[i][numCols+3]=mirrorFramedAry[i][numCols+1];
  }
  /*for(int i=0;i<numRows+4;i++){
   for(int j=0;j<numCols+4;j++){
     cout<<mirrorFramedAry[i][j]<<" ";
   }
   cout<<endl;
  }*/
}
void imgReformat(int** inAry,ofstream& outFile){
	int newmax=0;
	int newmin=100000;
	for(int r=2;r<numRows+2;r++){
	 for(int c=2;c<numCols+2;c++){
	   if(newmax<inAry[r][c]) newmax=inAry[r][c];
	   if(newmin>inAry[r][c]) newmin=inAry[r][c];
	 }
	}
	cout<<"Rows "<<numRows<<" Cols "<<numCols<<" minVal "<<newmin<<" maxVal "<<newmax<<endl;
	outFile<<"Rows "<<numRows<<" Cols "<<numCols<<" minVal "<<newmin<<" maxVal "<<newmax<<"\n";
	string str=to_string(maxVal); // C++ build-in
	int Width=str.length();
	for(int r=2;r<numRows+2;r++){
	 for(int c=2;c<numCols+2;c++){
	  cout<<inAry[r][c];
	  outFile<<inAry[r][c];
	  str=to_string(inAry[r][c]);
	  for(int WW=str.length();WW<Width+1;WW++){
	    outFile<<" ";
	    cout<<" ";
	  }
	 }
	 outFile<<"\n";
	 cout<<endl;
	}
}
void loadNeighborAry(int** mirrorFramedAry,int i,int j,int* neighborAry){
 for(int i=0;i<25;i++) neighborAry[i]=0;
 int counter=0;
 for(int a=i-2;a<=i+2;a++){
  for(int b=j-2;b<=j+2;b++){
	neighborAry[counter]=mirrorFramedAry[a][b];
	counter++;
  }
 }
 //for(int i=0;i<25;i++) cout<<neighborAry[i];
}
void computeAvg(int** mirrorFramedAry,int** avgAry){
for(int i=2;i<numRows+2;i++){
 for(int j=2;j<numCols+2;j++){
   loadNeighborAry(mirrorFramedAry, i, j,neighborAry);
   int sum=0;
   for(int k=0;k<25;k++){
	 sum=sum+neighborAry[k];
    }
    avgAry[i][j]=sum/25;
  }
 }
}
void computeMedian(int** mirrorFramedAry,int** medianAry){
for(int i=2;i<numRows+2;i++){
 for(int j=2;j<numCols+2;j++){
   loadNeighborAry(mirrorFramedAry, i, j,neighborAry);
   //for(int z=0;z<25;z++) cout<<neighborAry[z]<<" ";
   //cout<<endl;
   for(int k=1;k<25;k++){
	 for(int l=0;l<k;l++){
	   if(neighborAry[k]<neighborAry[l]){
		   int temp=neighborAry[l];
		   neighborAry[l]=neighborAry[k];
		   neighborAry[k]=temp;
	   }
	 }
    }
   //for(int z=0;z<25;z++) cout<<neighborAry[z]<<" ";
   //cout<<endl;
    medianAry[i][j]=neighborAry[12];
  }
 }
}
int convolution(int* neighborAry,int* maskAry){
int result=0;
for(int i=0;i<25;i++){
	result += neighborAry[i] * maskAry[i];
}
return (result /maskWeight);
}
void computeGauss(int** mirrorFramedAry,int** GaussAry){
for(int i=2;i<numRows+2;i++){
 for(int j=2;j<numCols+2;j++){
   loadNeighborAry(mirrorFramedAry, i, j,neighborAry);
   GaussAry[i][j]=convolution(neighborAry, maskAry);
  }
 }
}
void binaryThreshold(int** Ary,int** thrAry){
  for(int i=0;i<numRows+4;i++){
   for(int j=0;j<numCols+4;j++){
	  thrAry[i][j]=0;
   }
  }
  for(int i=2;i<numRows+2;i++){
   for(int j=2;j<numCols+2;j++){
  	 if(Ary[i][j]<thr) thrAry[i][j]=0;
  	 if(Ary[i][j]>=thr) thrAry[i][j]=1;
   }
  }
}
void prettyPrint(int** Ary,ofstream& outFile){
	for(int i=2;i<numRows+2;i++){
	   for(int j=2;j<numCols+2;j++){
	  	 if(Ary[i][j]>0){
	  		 outFile<<Ary[i][j]<<" ";
	  		 cout<<Ary[i][j]<<" ";
	  		//outFile<<Ary[i][j]<<" ";
	  	    //cout<<Ary[i][j]<<" ";
	  	 }
	  	 else{
	  		outFile<<"  ";
	  	    cout<<"  ";
	  		//outFile<<Ary[i][j]<<" ";
	  		//cout<<Ary[i][j]<<" ";
	  	 }
	  }
	  outFile<<"\n";
	  cout<<endl;
	}
}
int main(int argc,char** argv) {
	ifstream inFile,maskFile;
	inFile.open(argv[1]);
	maskFile.open(argv[2]);
	thr=atoi(argv[3]);
	ofstream AvgOutFile,MedianOutFile,GaussOutFile,deBugFile;
	//imgOutFile.open(argv[4]);
	AvgOutFile.open(argv[4]);
	MedianOutFile.open(argv[5]);
	GaussOutFile.open(argv[6]);
	deBugFile.open(argv[7]);
	cout <<"Threshold value "<<thr<<endl;
	deBugFile <<"Threshold value "<<thr<<"\n";
	int numberindex1=0,numberindex2=0;
	string currentst1="",currentst2="";
	while(inFile>>currentst1) {
	  numberindex1++;
	  int currval1= stoi(currentst1);
	  if(numberindex1==1) numRows=currval1;
	  if(numberindex1==2) numCols=currval1;
	  if(numberindex1==3) minVal=currval1;
	  if(numberindex1==4) {
	    maxVal=currval1;
	    break;
	  }
	}
	while(maskFile>>currentst2) {
		  numberindex2++;
		  int currval2= stoi(currentst2);
		  if(numberindex2==1) maskRows=currval2;
		  if(numberindex2==2) maskCols=currval2;
		  if(numberindex2==3) maskMin=currval2;
		  if(numberindex2==4) {
		    maskMax=currval2;
		    break;
		  }
   }
	//int mirrorFramedAry[][]; // a 2D array of size numRows + 4 by numCols + 4. dynamically allocate.
	//int avgAry[][]; // a 2D array of size numRows + 4 by numCols + 4. dynamically allocate.
	//int medianAry[][]; // a 2D array of size numRows + 4 by numCols + 4. dynamically allocate.
	//int GaussAry[][]; // a 2D array of size numRows + 4 by numCols + 4. dynamically allocate.
	//int thrAry[][]; // a 2D array of size numRows + 4 by numCols + 4. dynamically allocate.
	// to hold the threshold result for each operation.
	//int neighborAry[25]; //1-D array to hold a pixel[i,j]’s 5x5 neighbors to ease computation.
	//int maskAry[25]; // to hold the 25 pixels of mask to ease computation.
	int **mirrorFramedAry = (int **) malloc(sizeof(int*) * (numRows+4));
	int **avgAry = (int **) malloc(sizeof(int*) * (numRows+4));
	int **medianAry = (int **) malloc(sizeof(int*) * (numRows+4));
	int **GaussAry = (int **) malloc(sizeof(int*) * (numRows+4));
	int **thrAry = (int **) malloc(sizeof(int*) * (numRows+4));
	for(int i = 0; i < numRows+4; i++){
		   mirrorFramedAry[i] = (int *) malloc(sizeof(int) * (numCols+4));
		   avgAry[i] = (int *) malloc(sizeof(int) * (numCols+4));
		   medianAry[i] = (int *) malloc(sizeof(int) * (numCols+4));
		   GaussAry[i] = (int *) malloc(sizeof(int) * (numCols+4));
		   thrAry[i] = (int *) malloc(sizeof(int) * (numCols+4));
	}
    loadMaskAry(maskFile,maskAry);
    loadImage(inFile, mirrorFramedAry);
    mirrorFraming(mirrorFramedAry);
    imgReformat(mirrorFramedAry, deBugFile);
    computeAvg(mirrorFramedAry, avgAry);
    imgReformat(avgAry, deBugFile);
    binaryThreshold(avgAry, thrAry);
    prettyPrint(thrAry, AvgOutFile);
    computeMedian(mirrorFramedAry, medianAry);
    imgReformat(medianAry, deBugFile);
    binaryThreshold(medianAry, thrAry);
    prettyPrint(thrAry, MedianOutFile);
    computeGauss(mirrorFramedAry, GaussAry);
    imgReformat(GaussAry, deBugFile);
    binaryThreshold(GaussAry, thrAry);
    prettyPrint(thrAry, GaussOutFile);
    inFile.close();
    maskFile.close();
    AvgOutFile.close();
    MedianOutFile.close();
    GaussOutFile.close();
    deBugFile.close();
	return 0;
}
