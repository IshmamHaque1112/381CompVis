//============================================================================
// Name        : HaqueI_Project8_CPPOriginal.cpp
// Author      : 
// Version     :
// Copyright   : Your copyright notice
// Description : Hello World in C++, Ansi-style
//============================================================================

#include <iostream>
#include <fstream>
#include <cmath>
#include <stdio.h>
#include <math.h>
#include <string>
#include <algorithm>
using namespace std;
int ThrValue,numRows, numCols, minVal, maxVal,numStructRows, numStructCols, StructMin, StructMax, rowOrigin, colOrigin;
int structElem[3]={1,1,1};
class boxNode{
public:
	int boxType=0; // 1 for zone; 2 for text-line.
	int minR=0; // with respect to the input image.
	int minC=0; // with respect to the input image.
	int maxR=0; // with respect to the input image.
	int maxC=0; // with respect to the input image.
    boxNode* next=NULL;
};
boxNode* listHead;

void zero2DAry(int** zeroFramedAry, int a, int b) {
	  for(int i=0;i<a;i++) {
		for(int j=0;j<b;j++) {
		 zeroFramedAry[i][j]=0;
		}
	  }
 }
void loadImage(ifstream& inFile,int** zeroFramedAry){
  int row=1,col=1;
  int counter=0;
  string loaded="";
  while(inFile>>loaded) {
  	int currval=stoi(loaded);
  	zeroFramedAry[row][col]=currval;
  	counter++;
  	col++;
  	if(col==1+numCols){
  	 row=row+1;
  	 col=1;
  	}
  	if(counter==numRows*numCols) break;
  }
}
void imgReformat(int** inAry,ofstream& outFile){
	int newmax=0;
	int newmin=100000;
	for(int r=1;r<numRows+1;r++){
	 for(int c=1;c<numCols+1;c++){
	   if(newmax<inAry[r][c]) newmax=inAry[r][c];
	   if(newmin>inAry[r][c]) newmin=inAry[r][c];
	 }
	}
	outFile<<"Rows "<<numRows<<" Cols "<<numCols<<" minVal "<<newmin<<" maxVal "<<newmax<<"\n";
	string str=to_string(maxVal); // C++ build-in
	int Width=str.length();
	for(int r=1;r<numRows+1;r++){
	 for(int c=1;c<numCols+1;c++){
	  if(inAry[r][c]!=0) outFile<<inAry[r][c];
	  if(inAry[r][c]==0) outFile<<".";
	  str=to_string(inAry[r][c]);
	  for(int WW=str.length()-1;WW<Width+1;WW++){
		 outFile<<" ";
	  }
	 }
	 outFile<<"\n";
	}
}
void computePP(int** imgAry,int* HPP,int* VPP){
	for(int i=0;i<numRows+2;i++){
	 for(int j=0;j<numCols+2;j++){
		if(imgAry[i][j]==1){
			HPP[i]=HPP[i]+1;
			VPP[j]=VPP[j]+1;
		}
	 }
	}
}
boxNode* computeZoneBox(int* binHPP,int* binVPP){
int minR=1;
int minC=1;
int maxR=numRows;
int maxC=numCols;
while((binHPP[minR]==0) && (minR<=numRows)){
	minR++;
}
while((binHPP[maxR]==0) && (maxR>=1)){
	maxR--;
}
while((binVPP[minC]==0) && (minC<=numCols)){
	minC++;
}
while((binVPP[maxC]==0) && (maxC>=1)){
    maxC--;
}
boxNode* b=new boxNode();
b->boxType=1;
b->minR=minR;
b->maxR=maxR;
b->minC=minC;
b->maxC=maxC;
b->next=NULL;
return b;
}
int computePPruns (int* PP,int lastIndex){
int numRuns=0;
int index=1;
while(index<=lastIndex){
	while(PP[index]==0 && index<=lastIndex){
	  index++;
	}
	if(index>lastIndex) break;
	while(PP[index]>0 && index<=lastIndex){
	   index++;
    }
	numRuns++;
}
 return numRuns;
}
int computeDirection(int runsHPP,int runsVPP,ofstream& outFile1){
  int factor=2; //
  int direction= 0;
  if(runsHPP <= 2 && runsVPP <= 2) outFile1<<"the zone may be a non-text zone"<<endl;
  else if(runsHPP >= factor * runsVPP){
	  outFile1<<"the document reading direction is horizontal!"<<endl;
	  direction=1;
  }
  else if(runsVPP >= factor * runsHPP){
	  outFile1<<" the document reading direction is vertical!"<<endl;
      direction=2;
  }
  else outFile1<<"the zone may be a non-text zone"<<endl;
  return direction;
}
void listInsert(boxNode* a,boxNode* b){
 b->next=a->next;
 a->next=b;
}
void computeHorizontalTextBox (boxNode* zoneBox,int* PP,int lastIndex){
int minR=zoneBox->minR;
int minC=zoneBox->minC;
int maxR=minR; // Start at the beginning.
int maxC=zoneBox->maxC;
while(PP[maxR]==0 && maxR<=lastIndex){
	if(PP[maxR] == 0) maxR++;
}
minR=maxR; // update minR
while(minR<=lastIndex){
	while(PP[maxR]>0 && maxR<=lastIndex){
		if(PP[maxR]> 0) maxR++;
	}
	boxNode* b=new boxNode();
	b->boxType=2;
	b->minR=minR;
	b->maxR=maxR;
	b->minC=minC;
	b->maxC=maxC;
	b->next=NULL;
    listInsert(listHead,b);
    minR=maxR;
    while(PP[minR]==0 && minR<=lastIndex){
    	if(PP[minR] == 0) minR++;
    }
    maxR=minR;
}
}
void computeVerticalTextBox (boxNode* zoneBox,int* PP,int lastIndex){
int minR=zoneBox->minR;
int minC=zoneBox->minC;
int maxR=zoneBox->maxR; // Start at the beginning.
int maxC=minC;
while(PP[maxC]==0 && maxC<=lastIndex){
	if(PP[maxC] == 0) maxC++;
}
minC=maxC; // update minR
while(minC<=lastIndex){
	while(PP[maxC]>0 && maxC<=lastIndex){
		if(PP[maxC]> 0) maxC++;
	}
	boxNode* b=new boxNode();
	b->boxType=2;
	b->minR=minR;
	b->maxR=maxR;
	b->minC=minC;
	b->maxC=maxC;
	b->next=NULL;
    listInsert(listHead,b);
    minC=maxC;
    while(PP[minC]==0 && minC<=lastIndex){
    	if(PP[minC] == 0) minC++;
    }
    maxC=minC;
}
}
   void onePixelDilation(int i,int origin,int* inAry,int* outAry,int* structAry) {
    int Offset=i - origin;
    int index=0;
    while(index<3) {
     int cIndex=0;
     if(structAry[index]>0) outAry[Offset + index]=1;
     index++;
    }
   }
   static void onePixelErosion(int i,int origin,int* inAry,int* outAry,int* structAry) {
	 int Offset=i - origin;
     bool matchFlag=true;
     int index=0;
     while((matchFlag == true)&&(index<3)) {
    	  if((structAry[index]>0)&&(inAry[Offset+index]) <= 0) matchFlag=false;
      index++;
     }
    if(matchFlag==true) outAry[i]=1;
    else if(matchFlag==false) outAry[i]=0;
   }
    void ComputeDilation(int* inAry,int* outAry,int* structAry,int origin,int length){
     for(int i=1;i<length-1;i++) {
    	//if(inAry[i]>0) onePixelDilation(i, origin, inAry, outAry, structAry);
    	if(inAry[i]>0){
    		outAry[i-1]=1;
    		outAry[i]=1;
    		outAry[i+1]=1;
    	}
     }
    }
    void ComputeErosion(int* inAry,int* outAry,int* structAry,int origin,int length){
	    for(int i=1;i<length-1;i++) {
		  	//if(inAry[i]>0) onePixelErosion(i,origin, inAry, outAry, structAry);
	    	if((inAry[i]>0)&&(inAry[i-1]>0)&&(inAry[i+1]>0)){
	    		//outAry[i-1]=0;
	    		outAry[i]=1;
	    		//outAry[i+1]=0;
	    	}
	    }
	}
    void morphClosing(int* inAry,int* morphAry,int* structAry,int* tempAry,int origin,int length){
	 for(int i=0;i<length;i++){
	   tempAry[i]=0;
	 }
     ComputeDilation(inAry, tempAry, structAry,origin,length);
     for(int i=0;i<length;i++){
        cout<<tempAry[i]<<" ";
     }
     cout<<endl;
     ComputeErosion(tempAry, morphAry, structAry,origin,length);
     for(int i=0;i<length;i++){
       cout<<morphAry[i]<<" ";
      }
       cout<<endl;
   }
void overlayBox(boxNode* a,ofstream& outFile2,int** zeroFramedAry){
	boxNode* currnode=a->next;
	int label=9;
	while(true){
		int minRow=currnode->minR;
		int minCol=currnode->minC;
		int maxRow=currnode->maxR;
		int maxCol=currnode->maxC;
		int boxType=currnode->boxType;
		for(int i=minCol;i<=maxCol;i++){
		  zeroFramedAry[minRow][i]=9;
		  zeroFramedAry[maxRow][i]=9;
		}
		for(int i=minRow;i<=maxRow;i++){
		   zeroFramedAry[i][minCol]=9;
		   zeroFramedAry[i][maxCol]=9;
		}
		if(currnode->next==NULL) break;
		currnode=currnode->next;
	}
	imgReformat(zeroFramedAry,outFile2);
}
void printBox(boxNode* a,ofstream& outFile2){
	boxNode* currnode=a->next;
	while(true){
		int minRow=currnode->minR;
		int minCol=currnode->minC;
		int maxRow=currnode->maxR;
		int maxCol=currnode->maxC;
		int boxType=currnode->boxType;
		outFile2<<boxType<<endl;
		outFile2<<minRow<<" "<<minCol<<" "<<maxRow<<" "<<maxCol<<endl;
		if(currnode->next==NULL) break;
		currnode=currnode->next;
	}
}
int main(int argc,char** argv) {
    listHead=new boxNode();
	ifstream inFile,structFile;
	ofstream outFile1,outFile2;
    inFile.open(argv[1]);
    ThrValue=atoi(argv[2]);
    structFile.open(argv[3]);
    outFile1.open(argv[4]);
    outFile2.open(argv[5]);
    string currentst1="";
    int numberindex1=0;
    string currentst2="";
    int numberindex2=0;
    while(inFile>>currentst1) {
     numberindex1++;
     int currval1= stoi(currentst1);
     if(numberindex1==1) numRows=currval1;
     if(numberindex1==2) numCols=currval1;
     if(numberindex1==3) minVal=currval1;
     if(numberindex1==4) {
    	maxVal=currval1;
    	break;
     }
    }
    while(structFile>>currentst2) {
         numberindex2++;
         int currval2= stoi(currentst2);
         if(numberindex2==1) numStructRows=currval2;
         if(numberindex2==2) numStructCols=currval2;
         if(numberindex2==3) StructMin=currval2;
         if(numberindex2==4) StructMax=currval2;
         if(numberindex2==5) rowOrigin=currval2;
         if(numberindex2==6) {
        	colOrigin=currval2;
        	break;
         }
    }
    int *HPP = (int *) malloc(sizeof(int) * (numRows+2));
    int *morphHPP = (int *) malloc(sizeof(int) * (numRows+2));
    int *tempHPP = (int *) malloc(sizeof(int) * (numRows+2));
    int *binHPP = (int *) malloc(sizeof(int) * (numRows+2));
    int *VPP = (int *) malloc(sizeof(int) * (numCols+2));
    int *binVPP = (int *) malloc(sizeof(int) * (numCols+2));
    int *tempVPP = (int *) malloc(sizeof(int) * (numCols+2));
    int *morphVPP = (int *) malloc(sizeof(int) * (numCols+2));
    int **imgAry = (int **) malloc(sizeof(int*) * (numRows+2));
    int **imgArytemp = (int **) malloc(sizeof(int*) * (numRows+2));
    for(int i = 0; i < numRows+2; i++){
      imgAry[i] = (int *) malloc(sizeof(int) * (numCols+2));
      imgArytemp[i] = (int *) malloc(sizeof(int) * (numCols+2));
    }
    for(int i = 0; i < numRows+2; i++){
       HPP[i]=0;
       morphHPP[i]=0;
       //cout<<HPP[i]<<endl;
     }
    for(int i = 0; i < numCols+2; i++){
       VPP[i]=0;
       morphVPP[i]=0;
     }
    zero2DAry(imgAry,numRows+2,numCols+2);
    loadImage(inFile,imgAry);
    for(int i=0;i<numRows+2;i++){
     for(int j=0;j<numCols+2;j++){
    	imgArytemp[i][j]=imgAry[i][j];
     }
    }
    outFile1<<"Below is the input image"<<endl;
    imgReformat(imgAry, outFile1);
    computePP(imgAry,HPP,VPP);
    outFile2<<"Below is the HPP"<<endl;
    for(int i=0;i<numRows+2;i++){
    	int curr=HPP[i];
    	outFile2<<curr<<" ";
    }
    outFile2<<endl;
    outFile2<<"Below is the VPP"<<endl;
    for(int i=0;i<numCols+2;i++){
    	int curr=VPP[i];
       outFile2<<curr<<" ";
     }
     outFile2<<endl;
     for(int i=0;i<numRows+2;i++){
        if(HPP[i]<ThrValue) binHPP[i]=0;
        else binHPP[i]=1;
     }
     for(int i=0;i<numCols+2;i++){
             if(VPP[i]<ThrValue) binVPP[i]=0;
             else binVPP[i]=1;
      }
     outFile2<<"Below is binHPP"<<endl;
     for(int i=0;i<numRows+2;i++){
     	    int curr=binHPP[i];
         	outFile2<<curr<<" ";
     }
     outFile2<<endl;
     outFile2<<"Below is binVPP"<<endl;
     for(int i=0;i<numCols+2;i++){
     	    int curr=binVPP[i];
            outFile2<<curr<<" ";
     }
     outFile2<<endl;
     //cout<<369<<endl;
     boxNode* zbox=computeZoneBox(binHPP, binVPP);
     //cout<<371<<endl;
     listInsert(listHead,zbox);
     //cout<<373<<endl;
     outFile2<<" Below is the linked list after insert input zone box"<<endl;
     printBox(listHead, outFile2);
     //cout<<listHead->next->boxType;
     morphClosing(binHPP,morphHPP,structElem,tempHPP,rowOrigin,numRows+2);
     morphClosing(binVPP,morphVPP,structElem,tempVPP,colOrigin,numCols+2);
     outFile2<<"Below is morphHPP after performing morphClosing on HPP"<<endl;
     for(int i=0;i<numRows+2;i++){
          	    int curr=morphHPP[i];
              	outFile2<<curr<<" ";
      }
     outFile2<<endl;
     outFile2<<"Below is morphVPP after performing morphClosing on VPP"<<endl;
     for(int i=0;i<numCols+2;i++){
          	    int curr=morphVPP[i];
                 outFile2<<curr<<" ";
      }
     outFile2<<endl;
    int runsHPP=computePPruns(morphHPP, numRows);
    int runsVPP=computePPruns(morphVPP, numCols);
    outFile2<<"The number of runs in morphHPP-runsHPP is "<<runsHPP<<endl;// fill in value.
    outFile2<<"The number of runs in morphVPP – runsVPP is "<<runsVPP<<endl; // fill in value.
    int readingDirection=computeDirection(runsHPP, runsVPP,outFile1);
    outFile2<<"readingDirection is "<<readingDirection<<endl; // fill in value.
    if(readingDirection == 1) computeHorizontalTextBox(zbox, morphHPP, numRows);
    else if(readingDirection == 2) computeVerticalTextBox(zbox, morphVPP, numCols);
    outFile1<<"Below is the input image overlay with bounding boxes"<<endl;
    overlayBox(listHead,outFile1,imgAry);
    outFile1<<"Output the boxNode in the list "<<endl;
    printBox(listHead, outFile1);
     inFile.close();
     structFile.close();
     outFile1.close();
     outFile2.close();
	return 0;
}
