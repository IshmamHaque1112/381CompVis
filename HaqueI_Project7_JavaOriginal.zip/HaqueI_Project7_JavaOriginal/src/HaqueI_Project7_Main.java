import java.io.*;
import java.util.*;
public class HaqueI_Project7_Main {
	static int numRows1, numCols1, minVal1, maxVal1;
	static int numRows2, numCols2, minVal2, maxVal2;
	static int label=0; // The component label
	static int numPixels=0; // total number of pixels in the cc.
	static int minRow=0; // with respect to the input image.
	static int minCol=0; // with respect to the input image.
	static int maxRow=0; // with respect to the input image.
	static int maxCol=0; // with respect to the input image.
	static int zeroTable[] = {6, 0, 0, 2, 2, 4, 4, 6};
	static int coordOffsetRows[]= {0,-1,-1,-1,0,1,1,1};
	static int coordOffsetCols[]= {1,1,0,-1,-1,-1,0,1};
    static ArrayList<Integer> boundaryrow = new ArrayList<Integer>();
    static ArrayList<Integer> boundarycol = new ArrayList<Integer>();
    static ArrayList<Integer> boundarylabel = new ArrayList<Integer>();
	static int[][] imgAry=null;
	static void loadImage(Scanner imgFile,int[][] imgAry, int rowSize, int colSize) {
		  for(int i=1;i<rowSize+1;i++) {
			for(int j=1;j<colSize+1;j++) {
				if(imgFile.hasNext()) {
				 int currval= Integer.parseInt(imgFile.next());
				 imgAry[i][j]=currval;
				}
			}
		  } 
	 }
	static void loadCCAry(int cclabel,int[][] imgAry,int[][] CCAry, int rowSize, int colSize) {
		  for(int i=1;i<rowSize+1;i++) {
			for(int j=1;j<colSize+1;j++) {
				 int currval=imgAry[i][j];
				 if(cclabel==currval) CCAry[i][j]=currval;
			}
		  } 
	 }
	static void reformatprettyPrint(int[][] zeroFramedAry,BufferedWriter outFile1, int r1,int c1) throws IOException{
		int newmax=0;
		int newmin=100000;
		for(int i=1;i<r1+1;i++) {
			for(int j=1;j<c1+1;j++) {
		   if(newmax<zeroFramedAry[i][j]) newmax=zeroFramedAry[i][j];
		   if(newmin>zeroFramedAry[i][j]) newmin=zeroFramedAry[i][j];
		 }
		}
		outFile1.write(Integer.toString(numRows1)+" "+Integer.toString(numCols1)+" "+Integer.toString(newmin)+" "+Integer.toString(newmax));
		outFile1.newLine();
		String str=String.valueOf(newmax);
		int Width=str.length();
		for(int r=1;r<r1+1;r++){
		 for(int c=1;c<c1+1;c++){
		    //outFile1.write(Integer.toString(zeroFramedAry[r][c]));
		  if(zeroFramedAry[r][c]!=0) outFile1.write(Integer.toString(zeroFramedAry[r][c]));
		  if(zeroFramedAry[r][c]==0) outFile1.write(".");
		  str=String.valueOf(zeroFramedAry[r][c]);
		  for(int WW=str.length()-1;WW<Width+1;WW++){
			 outFile1.write(" ");
		  }
		 }
		 outFile1.newLine();
		}	
	}
	static void setzeroAry(int[][] imgAry, int rowSize, int colSize) {
		  for(int i=0;i<rowSize;i++) {
			for(int j=0;j<colSize;j++) {
			 imgAry[i][j]=0;	
			}  
		  } 
	}
	static int findNextP(int currentrow,int currentcol,int lastQ,BufferedWriter deBugFile) throws IOException {
	 deBugFile.write("entering findNextP method \n");
	 int index=lastQ;
	 int chainDir=0;
	 boolean found=false;
	 while(found==false) {
		int iRow=currentrow+coordOffsetRows[index];
		int jCol=currentcol + coordOffsetCols[index];
        if(imgAry[iRow][jCol]==label) {
        	chainDir=index;
        	found=true;
        }
        else index=(index+1)%8;
	 }
	 deBugFile.write("leaving findNextP method \n");
	 deBugFile.write("chainDir = "+Integer.toString(chainDir)+"\n"); // fill in value;
	 return chainDir;
	}
	static void getChainCode(int[][] CCAry,BufferedWriter chainCodeFile,BufferedWriter deBugFile) throws IOException {
	 deBugFile.write("entering getChainCode method \n");
	 int label1=label;
	 int startrow=0;
	 int startcol=0;
	 int currentrow=0;
	 int currentcol=0;
	 int lastQ=4;
	 boolean discovered=false;
	 for(int iRow=1;iRow<numRows1+1;iRow++) {
	  for(int jCol=1;jCol<numCols1+1;jCol++) {
		  if((CCAry[iRow][jCol]==label1)&&(discovered==false)){
			 chainCodeFile.write(label1+" "+iRow+" "+jCol+"\n"); 
			 startrow=iRow;
			 startcol=jCol;
			 currentrow=iRow;
			 currentcol=jCol;
			 lastQ=4;
			 discovered=true;
		  }
	   }
	  }
	  while(true) {
		int nextQ=(lastQ+1)%8;
		int PchainDir=findNextP(currentrow,currentcol, nextQ, deBugFile);
		chainCodeFile.write(PchainDir+" ");
		int nextrow=currentrow+coordOffsetRows[PchainDir];
		int nextcol=currentcol+coordOffsetCols[PchainDir];
		int cr=currentrow;
		int cc=currentcol;
	    currentrow=nextrow;
		currentcol=nextcol;
		boundaryrow.add(currentrow);
		boundarycol.add(currentcol);
		boundarylabel.add(label1);
		if(PchainDir==0) lastQ=zeroTable[7];
		else lastQ=zeroTable[PchainDir-1];
		deBugFile.write("lastQ = "+lastQ+" "+"nextQ = "+nextQ+" currentP.row = "+cr+" currentP.col ="+cc+" nextP.row = "+nextrow+" nextP.col = "+nextcol+"\n");
		if((currentrow==startrow)&&(startcol==currentcol)) {
		  //System.out.println(currentrow+" "+currentcol+"Yes");
		  chainCodeFile.write("\n");
		  break;
		  }
		}
	 deBugFile.write("leaving getChainCode \n");
	}
	static void constructBoundary(int[][] imgAry,BufferedWriter BoundaryFile) throws IOException{
		setzeroAry(imgAry,numRows2+2,numCols2+2);
		for(int i=0;i<boundaryrow.size();i++) {
		  imgAry[boundaryrow.get(i)][boundarycol.get(i)]=boundarylabel.get(i);
		}
		reformatprettyPrint(imgAry,BoundaryFile,numRows2,numCols2);
	}
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner labelFile= new Scanner(new FileReader(args[0]));
		Scanner propFile= new Scanner(new FileReader(args[1]));
		BufferedWriter deBugFile=new BufferedWriter(new FileWriter(args[2]));
		int numberindex1=0;
		int numberindex2=0;
		while(labelFile.hasNext()) {
			numberindex1++;
			int currval= Integer.parseInt(labelFile.next());
		    if(numberindex1==1) numRows1=currval;
		    if(numberindex1==2) numCols1=currval;
		    if(numberindex1==3) minVal1=currval;
		    if(numberindex1==4) {
		      maxVal1=currval;
		      break;
		    }  
		}
		while(propFile.hasNext()) {
			numberindex2++;
			int currval= Integer.parseInt(propFile.next());
		    if(numberindex2==1) numRows2=currval;
		    if(numberindex2==2) numCols2=currval;
		    if(numberindex2==3) minVal2=currval;
		    if(numberindex2==4) {
		      maxVal2=currval;
		      break;
		    }  
		}
		imgAry= new int[numRows1+2][numCols1+2];
		int numCC=Integer.parseInt(propFile.next());
		setzeroAry(imgAry,numRows1+2,numCols1+2);
		loadImage(labelFile,imgAry,numRows1,numCols1);
		deBugFile.write("imgrray \n");
		reformatprettyPrint(imgAry, deBugFile,numRows1,numCols1);
		int[][] CCAry= new int[numRows2+2][numCols2+2];
		setzeroAry(CCAry,numRows2+2,numCols2+2);
		String chainCodeFileName= args[1]+ "_chainCode.txt";
		String BoundaryFileName=args[1]+"_Boundary.txt";
		File chainCodeFile1=new File(chainCodeFileName);
		File BoundaryFile1=new File(BoundaryFileName);
		BufferedWriter chainCodeFile=new BufferedWriter(new FileWriter(chainCodeFile1));
		BufferedWriter BoundaryFile=new BufferedWriter(new FileWriter(BoundaryFile1));
		chainCodeFile.write(numRows2+" "+numCols2+" "+minVal2+" "+maxVal2+"\n"); // image header, one text line
		chainCodeFile.write(numCC+"\n"); // one text line
		for(int i=0;i<numCC;i++) {
		 label=Integer.parseInt(propFile.next());
		 numPixels=Integer.parseInt(propFile.next());
		 minRow=Integer.parseInt(propFile.next());
		 minCol=Integer.parseInt(propFile.next());
		 maxRow=Integer.parseInt(propFile.next());
		 maxCol=Integer.parseInt(propFile.next());
		 setzeroAry(CCAry,numRows2+2,numCols2+2);
		 loadCCAry(label,imgAry,CCAry,numRows2,numCols2);
		 deBugFile.write("CCarray "+label+"\n");
		 reformatprettyPrint(CCAry, deBugFile,numRows2,numCols2);
		 getChainCode(CCAry, chainCodeFile, deBugFile);
		}
		chainCodeFile.close();
		Scanner chainCodeFilescan= new Scanner(chainCodeFile1);
		deBugFile.write("Chain code file \n"); 
		while(chainCodeFilescan.hasNextLine()){  
		 deBugFile.write(chainCodeFilescan.nextLine());//returns the line that was skipped
		 deBugFile.newLine();
		}   
		int[][] BoundaryAry= new int[numRows2+2][numCols2+2];
		deBugFile.write("Boundary file \n");
		constructBoundary(BoundaryAry,BoundaryFile);
		constructBoundary(BoundaryAry,deBugFile);
		BoundaryFile.close();
		chainCodeFilescan.close();
        labelFile.close();
        propFile.close();
        deBugFile.close();
        
	}

}
