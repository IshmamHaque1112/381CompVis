import java.io.*;
import java.util.*;
public class HaqueI_Project3_Main {
   static int numImgRows=0, numImgCols=0, imgMin=0, imgMax=0,numStructRows=0, numStructCols=0, structMin=0, structMax=0,rowOrigin=0, colOrigin=0;
   static int rowFrameSize,colFrameSize,extraRows,extraCols,rowSize,colSize;
   static void zero2DAry(int[][] zeroFramedAry, int rowSize, int colSize) {
	  for(int i=0;i<rowSize;i++) {
		for(int j=0;j<colSize;j++) {
		 zeroFramedAry[i][j]=0;	
		}  
	  } 
   }
   static void loadImg(Scanner imgFile,int[][] zeroFramedAry) {
	  for(int i=rowFrameSize;i<rowFrameSize+numImgRows;i++) {
		for(int j=colFrameSize;j<colFrameSize+numImgCols;j++) {
			if(imgFile.hasNext()) {
			 int currval= Integer.parseInt(imgFile.next());
			 zeroFramedAry[i][j]=currval;
			}
		}
	  } 
   }
   static void loadstruct(Scanner elmFile,int[][] structAry) {
		  for(int i=0;i<numStructRows;i++) {
			for(int j=0;j<numStructCols;j++) {
				if(elmFile.hasNext()) {
				 int currval= Integer.parseInt(elmFile.next());
				 //System.out.println(currval);
				 structAry[i][j]=currval;
				}
			}
		  } 
   }
  static void imgReformat(int[][] inAry,BufferedWriter outFile) throws IOException{
		int newmax=0;
		int newmin=100000;
		for(int i=rowFrameSize;i<rowFrameSize+numImgRows;i++) {
			for(int j=colFrameSize;j<colFrameSize+numImgCols;j++) {
		   if(newmax<inAry[i][j]) newmax=inAry[i][j];
		   if(newmin>inAry[i][j]) newmin=inAry[i][j];
		 }
		}
		outFile.write("Picture without framing");
		outFile.newLine();
		outFile.write("Rows "+numImgRows+" Cols "+numImgCols+" minVal "+newmin+" maxVal "+newmax);
		outFile.newLine();
		for(int r=rowFrameSize;r<rowFrameSize+numImgRows;r++){
		 for(int c=colFrameSize;c<colFrameSize+numImgCols;c++){
		  outFile.write(Integer.toString(inAry[r][c]));
		  outFile.write(" ");
		 }
		 outFile.newLine();
		}
	}
   static void reframe(int[][] inAry,int[][] inAry2) {
	   for(int i=0;i<numImgRows;i++) {
		 for(int j=0;j<numImgCols;j++) {
			 inAry2[i][j]=inAry[i+1][j+1];
		 }  
	   }
   }
   static void copyArys(int[][] morphAry,int[][] zeroFramedAry) {
	   int row=morphAry.length; // row
	   int col= morphAry[0].length; // col
	   for(int i=0;i<row;i++) {
		 for(int j=0;j<col;j++) {
			 zeroFramedAry[i][j]=morphAry[i][j];
		 }  
	   }
	   //for(int i=0;i<row;i++) {
		//	 for(int j=0;j<col;j++) {
		//		 if(zeroFramedAry[i][j]!=morphAry[i][j]) System.out.println("False");
		//	 }  
	   //}
   }
   static void prettyPrint(int[][] inAry,BufferedWriter outFile) throws IOException{
	 int row=inAry.length; // row
	 int col= inAry[0].length; // col
	 int newmax=0;
	 int newmin=100000;
	 for(int i=0;i<row;i++) {
		for(int j=0;j<col;j++) {
		  if(newmax<inAry[i][j]) newmax=inAry[i][j];
		  if(newmin>inAry[i][j]) newmin=inAry[i][j];
		}
	 }
	 outFile.write("Rows "+row+" Cols "+col+" minVal "+newmin+" maxVal "+newmax);
	  outFile.newLine();
		for(int i=0;i<row;i++){
		   for(int j=0;j<col;j++){
		  	 if(inAry[i][j]>0){
		  		outFile.write("1 ");
		  	 }
		  	 else{
		  		outFile.write(". ");
		  	 }
		  }
		  outFile.newLine();
		}
	}
   static void onePixelDilation (int i,int j,int[][] inAry,int[][] outAry,int[][] structAry) {
    int iOffset=i - rowOrigin;
    int jOffset=j - colOrigin;
    System.out.println();
    // translation of image�s coordinate (i, j) with respected to the origin of the structuring element
    /*for(int rIndex=0;rIndex<numStructRows;rIndex++) {
	  for(int cIndex=0;cIndex<numStructCols;cIndex++) {
		  //System.out.println(rIndex+" "+cIndex+" "+(iOffset)+" "+(jOffset));
		  if(structAry[rIndex][cIndex]>0) outAry[iOffset+rIndex][jOffset+cIndex]=1;
	  }  
    }*/
    int rIndex=0;
    while(rIndex < numStructRows) {
     int cIndex=0;	
     while(cIndex<numStructCols) {
    	 if(structAry[rIndex][cIndex]>0) outAry[iOffset + rIndex][jOffset + cIndex]=1;
      cIndex++;	  
     }	 
     rIndex++;
    }
   }
   static void onePixelErosion (int i,int j,int[][] inAry,int[][] outAry,int[][] structAry) {
	 int iOffset=i - rowOrigin;
	 int jOffset=j - colOrigin;
	 //System.out.println(i+" "+j);
    // translation of image�s coordinate (i, j) with respected of the origin of the structuring element
     boolean matchFlag=true;
    /* while(matchFlag==true) {
    	//System.out.println();
    	for(int rIndex=0;rIndex<numStructRows;rIndex++) {
    	  for(int cIndex=0;cIndex<numStructCols;cIndex++) {
    		  //System.out.println((rIndex+iOffset)+" "+(cIndex+jOffset));
    		  if((structAry[rIndex][cIndex]>0)&&(inAry[iOffset + rIndex][jOffset + cIndex]<=0)) matchFlag=false;    	  
           }  
    	 }
    	break;
     }*/
     int rIndex=0;
     while((matchFlag == true)&&(rIndex < numStructRows)) {
      int cIndex=0;
      while((matchFlag==true)&&(cIndex<numStructCols)) {
    	  if((structAry[rIndex][cIndex]>0)&&(inAry[iOffset+rIndex][jOffset+cIndex]) <= 0) matchFlag=false;
       cIndex++;	  
      }	 
      rIndex++;
     }
    if(matchFlag==true) outAry[i][j]=1;
    else if(matchFlag==false) outAry[i][j]=0;
   }
   static void ComputeDilation(int[][] inAry,int[][] outAry,int[][] structAry){
    for(int i=rowFrameSize;i<rowSize;i++) {
	 for(int j=colFrameSize;j<colSize;j++) {
	  	if(inAry[i][j]>0) onePixelDilation(i, j, inAry, outAry, structAry);
	 }   
    }
    }
   static void ComputeErosion(int[][] inAry,int[][] outAry,int[][] structAry){
	    for(int i=rowFrameSize;i<rowSize;i++) {
		 for(int j=colFrameSize;j<colSize;j++) {
		  	if(inAry[i][j]>0) onePixelErosion(i, j, inAry, outAry, structAry);
		 }   
	    }
	}
   static void ComputeClosing(int[][] zeroFramedAry,int[][] morphAry,int[][] structAry,int[][] tempAry){
	 zero2DAry(tempAry ,rowSize,colSize);
     ComputeDilation(zeroFramedAry, tempAry, structAry);
     ComputeErosion(tempAry, morphAry, structAry);
   }
   static void ComputeOpening(int[][] zeroFramedAry,int[][] morphAry,int[][] structAry,int[][] tempAry){
	zero2DAry(tempAry ,rowSize,colSize);
	ComputeErosion(zeroFramedAry, tempAry, structAry);
    ComputeDilation(tempAry, morphAry, structAry);
   }
   static void basicOperations(int[][] zeroFramedAry,int[][] morphAry,int[][] structAry,int[][] tempAry,BufferedWriter outFile1) throws IOException {
    outFile1.write("entering basicOperations method");
    outFile1.newLine();
    zero2DAry(morphAry, rowSize, colSize);
    ComputeDilation(zeroFramedAry, morphAry, structAry);
    //System.out.println("Hu");
    outFile1.write("Printing result of ComputeDilation");
    outFile1.newLine();
    prettyPrint(morphAry, outFile1); // Prior to prettyPrint, write �Printing result of ComputeDilation.�
    zero2DAry(morphAry, rowSize, colSize);
    ComputeErosion(zeroFramedAry, morphAry, structAry);
    //System.out.println("Hu1");
    outFile1.write("Printing result of ComputeErosion");
    outFile1.newLine();
    prettyPrint(morphAry, outFile1); // Prior to prettyPrint, write �Printing result of ComputeErosion�.
    zero2DAry(morphAry, rowSize, colSize);
    ComputeOpening(zeroFramedAry, morphAry, structAry, tempAry);
    outFile1.write("Printing result of ComputeOpening");
    outFile1.newLine();
    prettyPrint(morphAry, outFile1); // Prior to prettyPrint, write �Printing result of ComputeOpening�
    zero2DAry(morphAry, rowSize, colSize);
    ComputeClosing(zeroFramedAry, morphAry, structAry, tempAry);
    outFile1.write("Printing result of ComputeClosing");
    outFile1.newLine();
    prettyPrint(morphAry, outFile1); // Prior to prettyPrint, write �Printing result of ComputeClosing.
    outFile1.write("exit basicOperations method");
    outFile1.newLine();
   }
   static void complexOperations(int[][] zeroFramedAry,int[][] morphAry,int[][] structAry,int[][] tempAry,BufferedWriter outFile2) throws IOException {
	   outFile2.write("entering complexOperations method");
	   outFile2.newLine();
	   int[][] zeroFramedAryA= new int[rowSize][colSize];
	   copyArys(zeroFramedAry,zeroFramedAryA);
	   zero2DAry(morphAry, rowSize, colSize);
	   zero2DAry(tempAry,rowSize,colSize);
	   ComputeOpening(zeroFramedAry, morphAry, structAry, tempAry);
	   outFile2.write("Pretty print the result of Opening");
	   outFile2.newLine();
	   prettyPrint(morphAry, outFile2);// Prior to prettyPrint, write � Pretty print the result of Opening.
	   copyArys(morphAry, zeroFramedAry); // copy morphAry to zeroFramedAry
	   zero2DAry(morphAry, rowSize, colSize);
	   ComputeClosing(zeroFramedAry, morphAry, structAry, tempAry);
	   outFile2.write("Pretty print the result of Opening follow by Closing");
	   outFile2.newLine();
	   prettyPrint(morphAry, outFile2); // Prior to prettyPrint, write � Pretty print the result of Opening follow by Closing.
	   copyArys(morphAry, zeroFramedAry); // copy morphAry to zeroFramedAry
	   copyArys(zeroFramedAryA,zeroFramedAry);
	   zero2DAry(morphAry, rowSize, colSize);
	   zero2DAry(tempAry ,rowSize,colSize);
	   ComputeClosing(zeroFramedAry, morphAry, structAry, tempAry);
	   outFile2.write("Pretty print the result of Closing.");
	   outFile2.newLine();
	   prettyPrint(morphAry, outFile2); // Prior to prettyPrint, write � Pretty print the result of Closing.
	   copyArys(morphAry, zeroFramedAry); // copy morphAry to zeroFramedAry
	   zero2DAry(morphAry, rowSize, colSize);
	   ComputeOpening(zeroFramedAry, morphAry, structAry, tempAry);
	   outFile2.write("Pretty print the result of Closing follow by Opening");
	   outFile2.newLine();
	   prettyPrint(morphAry, outFile2); // Prior to prettyPrint, write � Pretty print the result of Closing follow by Opening.
	   outFile2.write("Exit complexOperations method");
	   outFile2.newLine();
	}
   public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		Scanner imgFile= new Scanner(new FileReader(args[0]));
		Scanner elmFile= new Scanner(new FileReader(args[1]));
		BufferedWriter outFile1=new BufferedWriter(new FileWriter(args[2]));
		BufferedWriter outFile2=new BufferedWriter(new FileWriter(args[3]));
		int numberindex1=0;
		int numberindex2=0;
		while(imgFile.hasNext()) {
			numberindex1++;
			int currval= Integer.parseInt(imgFile.next());
		    if(numberindex1==1) numImgRows=currval;
		    if(numberindex1==2) numImgCols=currval;
		    if(numberindex1==3) imgMin=currval;
		    if(numberindex1==4) {
		      imgMax=currval;
		      break;
		    }  
		}
		while(elmFile.hasNext()) {
			numberindex2++;
			int currval= Integer.parseInt(elmFile.next());
		    if(numberindex2==1) numStructRows=currval;
		    if(numberindex2==2) numStructCols=currval;
		    if(numberindex2==3) structMin=currval;
		    if(numberindex2==4) structMax=currval;
		    if(numberindex2==5) rowOrigin=currval;
		    if(numberindex2==6) {
			      colOrigin=currval;
			      break;
			}
		}
		 rowFrameSize=(numStructRows / 2);// integer division, i.e., 3/2 is 1; 4/2 is 2; 5/2 is 2.
		 colFrameSize=(numStructCols / 2);
		 extraRows=(rowFrameSize * 2);
		 extraCols=(colFrameSize * 2);
		 rowSize=(numImgRows + extraRows);
		 colSize=(numImgCols + extraCols);
		int[][] zeroFramedAry= new int[rowSize][colSize]; // a dynamically allocate 2D array, size of rowSize by colSize, initialize to zero.
		int[][] zeroFramedAry2= new int[rowSize][colSize];
		int[][] morphAry=new int[rowSize][colSize]; // Same size as zeroFramedAry, initialize to zero.
		int[][] tempAry=new int[rowSize][colSize]; // Same size as zeroFramedAry, initialize to zero.
		// tempAry is used to store the intermediate result in opening and closing operations or in closing and opening.
		int[][] structAry=new int[numStructRows][numStructCols];//a dynamically allocate 2D array of size numStructRows by numStructCols, for structuring element.
		zero2DAry(zeroFramedAry, rowSize, colSize);
		zero2DAry(morphAry, rowSize, colSize);
		zero2DAry(tempAry, rowSize, colSize);
		loadImg(imgFile, zeroFramedAry);
		copyArys(zeroFramedAry,zeroFramedAry2);
		imgReformat(zeroFramedAry, outFile1);// with caption.
		//for(int i=0;i<rowSize;i++) {
		// for(int j=0;j<colSize;j++) {
		//	System.out.print(zeroFramedAry[i][j]+ " "); 
		// }
		// System.out.println();
		//}
		int[][] NoFrameAry=new int[numImgRows][numImgCols];
		reframe(zeroFramedAry,NoFrameAry);
		prettyPrint(NoFrameAry, outFile1); // with caption.
		zero2DAry(structAry, numStructRows, numStructCols);
		loadstruct(elmFile, structAry);
		//for(int i=0;i<numStructRows;i++) {
		//	   for(int j=0;j<numStructCols;j++) {
		//	   	System.out.print(structAry[i][j]+ " "); 
		//	   }
		//	   System.out.println();
		//}
		outFile1.write("Structuring Element");
	    outFile1.newLine();
		prettyPrint(structAry, outFile1); // with caption.
		basicOperations(zeroFramedAry, morphAry, structAry, tempAry, outFile1);
		copyArys(zeroFramedAry2,zeroFramedAry);
		complexOperations(zeroFramedAry, morphAry, structAry, tempAry, outFile2);
		imgFile.close();
		elmFile.close();
		outFile1.close();
		outFile2.close();
	}

}
